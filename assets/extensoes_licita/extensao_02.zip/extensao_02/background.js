// Background script para captura de página e geração de PDF
class PDFGenerator {
  constructor() {
    this.setupMessageHandlers();
  }

  setupMessageHandlers() {
    // Listener para mensagens do popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'generatePDF') {
        this.generatePDF(request.tabId)
          .then(result => sendResponse({ success: true, data: result }))
          .catch(error => sendResponse({ success: false, error: error.message }));
        return true; // Indica resposta assíncrona
      }
    });
  }

  async generatePDF(tabId) {
    try {
      // Mostrar notificação de processamento
      const notificationId = `processando-${Date.now()}`;
      await chrome.notifications.create(notificationId, {
        type: "basic",
        iconUrl: "icon.png",
        title: "Processando...",
        message: "Capturando página para PDF. Aguarde..."
      });

      // Obter informações da aba ativa
      const tab = tabId ? await chrome.tabs.get(tabId) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      
      if (!tab.url || (!tab.url.startsWith("http://") && !tab.url.startsWith("https://"))) {
        throw new Error("Esta extensão só funciona em páginas HTTP/HTTPS.");
      }

      // Capturar conteúdo da página usando content script
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'captureFullPage' });
      
      if (!response.success) {
        throw new Error(response.error || 'Erro ao capturar página');
      }

      // Gerar PDF usando a API de impressão do Chrome
      const pdfData = await this.createPDFFromHTML(response.data, tab);

      // Fazer download do PDF
      const filename = this.generateFilename(response.data.pageInfo.title);
      await chrome.downloads.download({
        url: `data:application/pdf;base64,${pdfData}`,
        filename: filename
      });

      // Atualizar notificação para sucesso
      await chrome.notifications.update(notificationId, {
        type: "basic",
        iconUrl: "icon.png",
        title: "Concluído!",
        message: `PDF gerado: ${filename}`
      });

      return { success: true, filename };

    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      
      // Mostrar notificação de erro
      await chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "Erro ao Gerar PDF",
        message: error.message
      });

      throw error;
    }
  }

  async createPDFFromHTML(pageData, tab) {
    try {
      // Usar a API de impressão do Chrome para gerar PDF
      const printOptions = {
        format: 'A4',
        printBackground: true,
        marginTop: 0.4,
        marginBottom: 0.4,
        marginLeft: 0.4,
        marginRight: 0.4,
        preferCSSPageSize: false
      };

      // Gerar PDF da aba atual
      const pdfBuffer = await chrome.tabs.printToPDF(tab.id, printOptions);
      
      // Converter ArrayBuffer para base64
      const base64String = this.arrayBufferToBase64(pdfBuffer);
      
      return base64String;

    } catch (error) {
      console.error("Erro ao criar PDF:", error);
      throw new Error("Falha ao gerar PDF: " + error.message);
    }
  }

  arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  generateFilename(title) {
    // Limpar título para usar como nome de arquivo
    const cleanTitle = title
      .replace(/[^\w\s-]/g, '') // Remover caracteres especiais
      .replace(/\s+/g, '-') // Substituir espaços por hífens
      .substring(0, 50); // Limitar tamanho
    
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    return `${cleanTitle || 'pagina'}-${timestamp}.pdf`;
  }
}

// Inicializar o gerador de PDF
new PDFGenerator();