// Content script para capturar o conteúdo completo da página
class PageCapture {
  constructor() {
    this.setupMessageListener();
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'captureFullPage') {
        this.captureFullPageContent()
          .then(result => sendResponse({ success: true, data: result }))
          .catch(error => sendResponse({ success: false, error: error.message }));
        return true; // Indica resposta assíncrona
      }
    });
  }

  async captureFullPageContent() {
    try {
      // Obter dimensões completas da página
      const fullHeight = Math.max(
        document.body.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.clientHeight,
        document.documentElement.scrollHeight,
        document.documentElement.offsetHeight
      );

      const fullWidth = Math.max(
        document.body.scrollWidth,
        document.body.offsetWidth,
        document.documentElement.clientWidth,
        document.documentElement.scrollWidth,
        document.documentElement.offsetWidth
      );

      // Salvar posição atual do scroll
      const originalScrollTop = window.pageYOffset;
      const originalScrollLeft = window.pageXOffset;

      // Criar canvas para capturar a página completa
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // Definir dimensões do canvas
      canvas.width = fullWidth;
      canvas.height = fullHeight;

      // Capturar o HTML completo da página
      const htmlContent = this.getCleanHTML();
      
      // Obter informações da página
      const pageInfo = {
        title: document.title,
        url: window.location.href,
        timestamp: new Date().toISOString(),
        dimensions: {
          width: fullWidth,
          height: fullHeight
        }
      };

      // Restaurar posição original do scroll
      window.scrollTo(originalScrollLeft, originalScrollTop);

      return {
        html: htmlContent,
        pageInfo: pageInfo,
        styles: this.extractStyles()
      };

    } catch (error) {
      console.error('Erro ao capturar página:', error);
      throw error;
    }
  }

  getCleanHTML() {
    // Clonar o documento para não afetar a página original
    const docClone = document.cloneNode(true);
    
    // Remover scripts e elementos desnecessários
    const scripts = docClone.querySelectorAll('script');
    scripts.forEach(script => script.remove());
    
    // Remover elementos de extensões do Chrome
    const chromeElements = docClone.querySelectorAll('[id*="chrome-extension"], [class*="chrome-extension"]');
    chromeElements.forEach(el => el.remove());

    // Converter URLs relativas em absolutas
    this.convertRelativeUrls(docClone);

    return docClone.documentElement.outerHTML;
  }

  convertRelativeUrls(doc) {
    const baseUrl = window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
    
    // Converter imagens
    const images = doc.querySelectorAll('img[src]');
    images.forEach(img => {
      if (img.src && !img.src.startsWith('http') && !img.src.startsWith('data:')) {
        img.src = new URL(img.src, window.location.href).href;
      }
    });

    // Converter links CSS
    const links = doc.querySelectorAll('link[href]');
    links.forEach(link => {
      if (link.href && !link.href.startsWith('http')) {
        link.href = new URL(link.href, window.location.href).href;
      }
    });
  }

  extractStyles() {
    const styles = [];
    
    // Extrair estilos inline
    const styleSheets = Array.from(document.styleSheets);
    
    styleSheets.forEach(sheet => {
      try {
        if (sheet.cssRules) {
          const rules = Array.from(sheet.cssRules);
          const cssText = rules.map(rule => rule.cssText).join('\n');
          if (cssText) {
            styles.push(cssText);
          }
        }
      } catch (e) {
        // Ignorar erros de CORS para estilos externos
        console.warn('Não foi possível acessar stylesheet:', e);
      }
    });

    // Extrair estilos computados dos elementos principais
    const computedStyles = this.extractComputedStyles();
    if (computedStyles) {
      styles.push(computedStyles);
    }

    return styles.join('\n');
  }

  extractComputedStyles() {
    const importantElements = document.querySelectorAll('body, main, article, section, div, p, h1, h2, h3, h4, h5, h6');
    let computedCSS = '';

    importantElements.forEach((element, index) => {
      if (index < 100) { // Limitar para evitar CSS muito grande
        const styles = window.getComputedStyle(element);
        const selector = this.generateSelector(element);
        
        const importantProps = [
          'display', 'position', 'width', 'height', 'margin', 'padding',
          'background', 'color', 'font-family', 'font-size', 'font-weight',
          'text-align', 'border', 'box-shadow'
        ];

        let elementCSS = `${selector} {\n`;
        importantProps.forEach(prop => {
          const value = styles.getPropertyValue(prop);
          if (value && value !== 'initial' && value !== 'normal') {
            elementCSS += `  ${prop}: ${value};\n`;
          }
        });
        elementCSS += '}\n';

        computedCSS += elementCSS;
      }
    });

    return computedCSS;
  }

  generateSelector(element) {
    if (element.id) {
      return `#${element.id}`;
    }
    
    if (element.className) {
      const classes = element.className.split(' ').filter(c => c.trim());
      if (classes.length > 0) {
        return `.${classes[0]}`;
      }
    }
    
    return element.tagName.toLowerCase();
  }
}

// Inicializar o capturador quando o script for carregado
new PageCapture();
