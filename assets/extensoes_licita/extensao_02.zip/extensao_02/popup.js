// Popup script para interface da extensão
class PopupController {
  constructor() {
    this.captureBtn = document.getElementById('captureBtn');
    this.captureVisibleBtn = document.getElementById('captureVisibleBtn');
    this.status = document.getElementById('status');
    this.statusMessage = document.getElementById('statusMessage');
    this.pageInfo = document.getElementById('pageInfo');
    this.pageTitle = document.getElementById('pageTitle');
    this.pageUrl = document.getElementById('pageUrl');

    this.init();
  }

  async init() {
    // Configurar event listeners
    this.captureBtn.addEventListener('click', () => this.handleCapture('full'));
    this.captureVisibleBtn.addEventListener('click', () => this.handleCapture('visible'));

    // Obter informações da aba atual
    await this.loadCurrentPageInfo();
  }

  async loadCurrentPageInfo() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tab) {
        this.pageTitle.textContent = tab.title || 'Título não disponível';
        this.pageUrl.textContent = tab.url || 'URL não disponível';
        this.pageInfo.style.display = 'block';

        // Verificar se a página é suportada
        if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
          this.showStatus('error', 'Esta extensão só funciona em páginas HTTP/HTTPS');
          this.captureBtn.disabled = true;
          this.captureVisibleBtn.disabled = true;
        }
      }
    } catch (error) {
      console.error('Erro ao obter informações da aba:', error);
      this.showStatus('error', 'Erro ao acessar informações da página');
    }
  }

  async handleCapture(type) {
    try {
      this.setButtonsState(true); // Desabilitar botões
      this.showStatus('processing', 'Processando captura...');

      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab) {
        throw new Error('Não foi possível acessar a aba atual');
      }

      if (type === 'full') {
        await this.captureFullPage(tab);
      } else {
        await this.captureVisibleArea(tab);
      }

    } catch (error) {
      console.error('Erro na captura:', error);
      this.showStatus('error', `Erro: ${error.message}`);
    } finally {
      this.setButtonsState(false); // Reabilitar botões
    }
  }

  async captureFullPage(tab) {
    try {
      // Enviar mensagem para o background script
      const response = await chrome.runtime.sendMessage({
        action: 'generatePDF',
        tabId: tab.id
      });

      if (response.success) {
        this.showStatus('success', `PDF gerado com sucesso: ${response.data.filename}`);
        
        // Fechar popup após 2 segundos
        setTimeout(() => {
          window.close();
        }, 2000);
      } else {
        throw new Error(response.error || 'Erro desconhecido');
      }

    } catch (error) {
      throw new Error(`Falha ao gerar PDF: ${error.message}`);
    }
  }

  async captureVisibleArea(tab) {
    try {
      // Capturar apenas a área visível usando a API de captura de tela
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png',
        quality: 100
      });

      // Converter para PDF usando canvas
      const pdfData = await this.convertImageToPDF(dataUrl, tab.title);
      
      // Fazer download
      const filename = this.generateFilename(tab.title, 'visivel');
      await chrome.downloads.download({
        url: `data:application/pdf;base64,${pdfData}`,
        filename: filename
      });

      this.showStatus('success', `PDF da área visível gerado: ${filename}`);
      
      // Fechar popup após 2 segundos
      setTimeout(() => {
        window.close();
      }, 2000);

    } catch (error) {
      throw new Error(`Falha ao capturar área visível: ${error.message}`);
    }
  }

  async convertImageToPDF(dataUrl, title) {
    return new Promise((resolve, reject) => {
      try {
        const img = new Image();
        img.onload = () => {
          // Criar canvas para desenhar a imagem
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');

          // Definir tamanho do canvas baseado na imagem
          canvas.width = img.width;
          canvas.height = img.height;

          // Desenhar a imagem no canvas
          ctx.drawImage(img, 0, 0);

          // Usar jsPDF para criar PDF (seria necessário incluir a biblioteca)
          // Por simplicidade, vamos usar uma abordagem alternativa
          // Converter canvas para blob e depois para base64
          canvas.toBlob((blob) => {
            const reader = new FileReader();
            reader.onload = () => {
              const base64 = reader.result.split(',')[1];
              
              // Criar um PDF simples com a imagem
              const pdfContent = this.createSimplePDF(base64, img.width, img.height);
              resolve(pdfContent);
            };
            reader.readAsDataURL(blob);
          }, 'image/png');
        };

        img.onerror = () => reject(new Error('Erro ao carregar imagem'));
        img.src = dataUrl;

      } catch (error) {
        reject(error);
      }
    });
  }

  createSimplePDF(imageBase64, width, height) {
    // Esta é uma implementação simplificada
    // Em uma implementação real, você usaria uma biblioteca como jsPDF
    // Por ora, retornamos a imagem como base64 (o Chrome pode lidar com isso)
    return imageBase64;
  }

  generateFilename(title, type = 'completa') {
    const cleanTitle = (title || 'pagina')
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 30);
    
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    return `${cleanTitle}-${type}-${timestamp}.pdf`;
  }

  showStatus(type, message) {
    this.status.className = `status ${type}`;
    
    if (type === 'processing') {
      this.statusMessage.innerHTML = `<div class="spinner"></div>${message}`;
    } else {
      this.statusMessage.textContent = message;
    }
    
    this.status.style.display = 'block';

    // Auto-hide após 5 segundos para mensagens de sucesso/erro
    if (type !== 'processing') {
      setTimeout(() => {
        this.status.style.display = 'none';
      }, 5000);
    }
  }

  setButtonsState(disabled) {
    this.captureBtn.disabled = disabled;
    this.captureVisibleBtn.disabled = disabled;
    
    if (disabled) {
      this.captureBtn.textContent = '⏳ Processando...';
      this.captureVisibleBtn.textContent = '⏳ Processando...';
    } else {
      this.captureBtn.textContent = '📥 Capturar Página Completa';
      this.captureVisibleBtn.textContent = '👁️ Capturar Área Visível';
    }
  }
}

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
  new PopupController();
});
