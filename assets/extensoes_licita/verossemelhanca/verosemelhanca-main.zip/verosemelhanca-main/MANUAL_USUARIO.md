

# Manual do Usuário - Sistema de Verificação de Verossimilhança

## 1. Introdução

Bem-vindo ao Sistema de Verificação de Verossimilhança. Este manual orienta sobre como utilizar a ferramenta para analisar arquivos Excel, comparar a descrição de itens com o Catálogo Nacional de Bens e Serviços (CNBS) e obter um relatório de itens com baixa similaridade.

## 2. Acesso ao Sistema

Para acessar o sistema, abra seu navegador de internet (Google Chrome, Firefox, etc.) e navegue até o endereço fornecido pela sua equipe de TI. A página inicial será exibida.

## 3. Interface Principal

A tela principal contém os seguintes elementos:

*   **Logo da Justiça Federal**: Identificação visual do sistema.
*   **Título**: "Verificar Verossimilhança".
*   **Formulário de Upload**: Área para selecionar e enviar seu arquivo Excel.
*   **Informações do Processamento**: Detalhes sobre como a análise é realizada.
*   **Botão de Ajuda**: Um ícone de interrogação (`?`) no canto inferior direito que abre um modal com instruções rápidas.

![Tela Inicial](static/images/arte03.png)

## 4. Passo a Passo para Usar o Sistema

### Passo 1: Preparar o Arquivo Excel

Antes de fazer o upload, garanta que seu arquivo `.xlsx` contenha as seguintes colunas, exatamente nesta ordem e com estes nomes:

1.  `Item`
2.  `Cód. SIASG`
3.  `Un.`
4.  `Discriminação`

O sistema usará a coluna `Discriminação` para a análise de similaridade.

### Passo 2: Fazer o Upload do Arquivo

1.  Na página inicial, clique no botão **"Escolher arquivo"**.
2.  Selecione o arquivo Excel preparado no seu computador.
3.  Após selecionar, o nome do arquivo aparecerá ao lado do botão.

### Passo 3: Enviar para Processamento

1.  Clique no botão azul **"Enviar Arquivo"**.
2.  O sistema iniciará o upload e, em seguida, o processamento. Uma mensagem de "Enviando arquivo..." e depois "Arquivo enviado com sucesso! Processando..." será exibida.
3.  Uma barra de progresso animada indicará que a análise está em andamento. **Não feche a página** durante esta etapa.

### Passo 4: Aguardar e Acompanhar o Resultado

*   O tempo de processamento pode variar dependendo do tamanho do arquivo e da carga do servidor.
*   Durante a análise, a seção **"Informações do Processamento"** será atualizada com:
    *   **Total de itens**: Quantidade de linhas analisadas.
    *   **Similaridades baixas**: Itens cuja descrição teve baixa correspondência com o CNBS.
    *   **Percentual**: Proporção de itens com baixa similaridade.
    *   **Tempo**: Duração do processamento.

### Passo 5: Baixar o Arquivo de Resultados

1.  Quando o processamento for concluído, uma mensagem de "Processamento concluído com sucesso!" aparecerá.
2.  O botão **"Baixar Resultados"** ficará visível.
3.  Clique neste botão para fazer o download de um novo arquivo Excel. Este arquivo conterá **apenas os itens que foram identificados com baixa similaridade**, permitindo uma análise focada.

## 5. Histórico de Processamentos

Você pode visualizar todos os arquivos que já foram processados clicando no link **"Histórico"** no menu superior.

Nesta página, você encontrará uma tabela com as seguintes informações:

*   **ID**: Identificador único de cada processamento.
*   **Arquivo**: Nome do arquivo original.
*   **Status**: Se o processamento foi `CONCLUÍDO`, está `PENDENTE` ou resultou em `ERRO`.
*   **Data**: Data e hora do envio.
*   **Ações**: Botões para **baixar** o resultado (se disponível) ou ver **detalhes**.

## 6. Detalhes do Processamento

Na tela de histórico, ao clicar no botão de detalhes (ícone de olho), você será levado a uma página com todas as informações de um processamento específico, incluindo a lista completa de itens com baixa similaridade e suas respectivas descrições e pontuações.

## 7. Solução de Problemas

*   **Erro no Upload**: Verifique se o seu arquivo está no formato `.xlsx` e se não excede o tamanho máximo permitido (informado na tela inicial).
*   **Processamento com Erro**: Se o status de um processamento for `ERRO`, tente enviar o arquivo novamente. Se o problema persistir, verifique se o arquivo está formatado corretamente. Caso o erro continue, contate o suporte técnico informando o ID do processamento.
*   **Página não carrega**: Verifique sua conexão com a internet e tente recarregar a página.

## 8. Contato

Para dúvidas ou problemas não abordados neste manual, entre em contato com a equipe de suporte de TI.

