"""
URLs principais do projeto verossimilhanca_project.

Sistema de Verificação de Verossimilhança
Migrado de Node.js para Django 3.2.25
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('verossimilhanca.urls')),
]

# Configurar título do admin
admin.site.site_header = 'Sistema de Verificação de Verossimilhança'
admin.site.site_title = 'Verossimilhança Admin'
admin.site.index_title = 'Administração do Sistema'

# Servir arquivos estáticos e de media em desenvolvimento
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Handlers de erro personalizados
handler404 = 'verossimilhanca.views.handler404'
handler500 = 'verossimilhanca.views.handler500'
