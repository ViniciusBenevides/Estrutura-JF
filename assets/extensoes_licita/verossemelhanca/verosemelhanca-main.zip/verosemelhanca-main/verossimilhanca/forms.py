"""
Formulários Django para o Sistema de Verificação de Verossimilhança.

Este módulo contém os formulários para upload de arquivos e
validação de dados de entrada.
"""

from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import UploadedFile


class UploadArquivoForm(forms.Form):
    """
    Formulário para upload de arquivos Excel.
    
    Valida o tipo de arquivo, tamanho e outros critérios
    antes do processamento.
    """
    
    arquivo = forms.FileField(
        label='Arquivo Excel',
        help_text='Selecione um arquivo Excel (.xlsx) para processamento',
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.xlsx',
            'id': 'file'
        })
    )
    
    def clean_arquivo(self):
        """Valida o arquivo enviado."""
        arquivo = self.cleaned_data.get('arquivo')
        
        if not arquivo:
            raise ValidationError('Nenhum arquivo foi selecionado.')
        
        # Verificar extensão
        nome_arquivo = arquivo.name.lower()
        extensoes_permitidas = settings.VEROSSIMILHANCA_SETTINGS.get('ALLOWED_EXTENSIONS', ['.xlsx'])
        
        if not any(nome_arquivo.endswith(ext) for ext in extensoes_permitidas):
            extensoes_str = ', '.join(extensoes_permitidas)
            raise ValidationError(f'Apenas arquivos com as extensões {extensoes_str} são aceitos.')
        
        # Verificar tamanho
        tamanho_maximo = settings.VEROSSIMILHANCA_SETTINGS.get('MAX_FILE_SIZE', 10485760)  # 10MB
        if arquivo.size > tamanho_maximo:
            tamanho_mb = tamanho_maximo / (1024 * 1024)
            raise ValidationError(f'O arquivo deve ter no máximo {tamanho_mb:.1f}MB.')
        
        # Verificar se o arquivo não está vazio
        if arquivo.size == 0:
            raise ValidationError('O arquivo está vazio.')
        
        return arquivo
    
    def clean(self):
        """Validação geral do formulário."""
        cleaned_data = super().clean()
        
        # Validações adicionais podem ser adicionadas aqui
        
        return cleaned_data


class ConfiguracaoSistemaForm(forms.Form):
    """
    Formulário para configuração de parâmetros do sistema.
    
    Permite ajustar limiar de similaridade e outros parâmetros.
    """
    
    limiar_similaridade = forms.FloatField(
        label='Limiar de Similaridade',
        help_text='Valor entre 0.0 e 1.0 para filtrar resultados (padrão: 0.65)',
        min_value=0.0,
        max_value=1.0,
        initial=0.65,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'step': '0.01',
            'placeholder': '0.65'
        })
    )
    
    tamanho_maximo_arquivo = forms.IntegerField(
        label='Tamanho Máximo do Arquivo (MB)',
        help_text='Tamanho máximo permitido para upload (padrão: 10MB)',
        min_value=1,
        max_value=100,
        initial=10,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '10'
        })
    )
    
    def clean_limiar_similaridade(self):
        """Valida o limiar de similaridade."""
        limiar = self.cleaned_data.get('limiar_similaridade')
        
        if limiar is None:
            raise ValidationError('Limiar de similaridade é obrigatório.')
        
        if not (0.0 <= limiar <= 1.0):
            raise ValidationError('Limiar deve estar entre 0.0 e 1.0.')
        
        return limiar
    
    def clean_tamanho_maximo_arquivo(self):
        """Valida o tamanho máximo do arquivo."""
        tamanho = self.cleaned_data.get('tamanho_maximo_arquivo')
        
        if tamanho is None:
            raise ValidationError('Tamanho máximo é obrigatório.')
        
        if tamanho < 1:
            raise ValidationError('Tamanho deve ser pelo menos 1MB.')
        
        if tamanho > 100:
            raise ValidationError('Tamanho não pode exceder 100MB.')
        
        return tamanho
