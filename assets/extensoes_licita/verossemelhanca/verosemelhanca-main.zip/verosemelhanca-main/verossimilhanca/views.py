"""
Views para o Sistema de Verificação de Verossimilhança.

Este módulo contém as views responsáveis por gerenciar a interface web,
upload de arquivos, processamento e download de resultados.
"""

import os
import json
import logging
import threading
from typing import Dict, Any
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponse, Http404, FileResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib import messages
from django.conf import settings
from django.core.files.storage import default_storage
from django.utils.decorators import method_decorator
from django.views.generic import View, TemplateView
from django.urls import reverse

from .models import ProcessamentoArquivo, ItemSimilaridade
from .services import processar_arquivo_async
from .forms import UploadArquivoForm

# Configurar logging
logger = logging.getLogger('verossimilhanca')


class HomeView(TemplateView):
    """
    View principal do sistema - página de upload.
    
    Exibe o formulário para upload de arquivos Excel e
    gerencia o processo de envio e processamento.
    """
    
    template_name = 'verossimilhanca/home.html'
    
    def get_context_data(self, **kwargs):
        """Adiciona dados de contexto para o template."""
        context = super().get_context_data(**kwargs)
        context.update({
            'form': UploadArquivoForm(),
            'max_file_size': settings.VEROSSIMILHANCA_SETTINGS.get('MAX_FILE_SIZE', 10485760),
            'allowed_extensions': settings.VEROSSIMILHANCA_SETTINGS.get('ALLOWED_EXTENSIONS', ['.xlsx']),
            'similarity_threshold': settings.VEROSSIMILHANCA_SETTINGS.get('SIMILARITY_THRESHOLD', 0.65),
        })
        return context


class UploadArquivoView(View):
    """
    View para processar upload de arquivos Excel.
    
    Recebe arquivos via POST, valida e inicia o processamento assíncrono.
    """
    
    def post(self, request):
        """Processa upload de arquivo Excel."""
        try:
            form = UploadArquivoForm(request.POST, request.FILES)
            
            if not form.is_valid():
                return JsonResponse({
                    'success': False,
                    'message': 'Dados do formulário inválidos.',
                    'errors': form.errors
                }, status=400)
            
            # Obter arquivo
            arquivo = request.FILES['arquivo']
            
            # Validar arquivo
            if not self._validar_arquivo(arquivo):
                return JsonResponse({
                    'success': False,
                    'message': 'Arquivo inválido. Apenas arquivos .xlsx são aceitos.'
                }, status=400)
            
            # Criar registro de processamento
            processamento = ProcessamentoArquivo.objects.create(
                usuario=request.user if request.user.is_authenticated else None,
                arquivo_original=arquivo,
                nome_arquivo_original=arquivo.name,
                tamanho_arquivo=arquivo.size,
                ip_usuario=self._get_client_ip(request),
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                limiar_similaridade=settings.VEROSSIMILHANCA_SETTINGS.get('SIMILARITY_THRESHOLD', 0.65)
            )
            
            # Iniciar processamento assíncrono
            thread = threading.Thread(
                target=processar_arquivo_async,
                args=(processamento.id,)
            )
            thread.daemon = True
            thread.start()
            
            logger.info(f"Processamento iniciado: ID {processamento.id}, Arquivo: {arquivo.name}")
            
            return JsonResponse({
                'success': True,
                'message': 'Arquivo enviado com sucesso! O processamento foi iniciado.',
                'processamento_id': processamento.id,
                'status_url': reverse('verossimilhanca:status', args=[processamento.id]),
                'download_url': reverse('verossimilhanca:download', args=[processamento.id])
            })
            
        except Exception as e:
            logger.error(f"Erro no upload: {str(e)}")
            return JsonResponse({
                'success': False,
                'message': f'Erro interno do servidor: {str(e)}'
            }, status=500)
    
    def _validar_arquivo(self, arquivo) -> bool:
        """Valida se o arquivo é válido."""
        # Verificar extensão
        nome_arquivo = arquivo.name.lower()
        extensoes_permitidas = settings.VEROSSIMILHANCA_SETTINGS.get('ALLOWED_EXTENSIONS', ['.xlsx'])
        
        if not any(nome_arquivo.endswith(ext) for ext in extensoes_permitidas):
            return False
        
        # Verificar tamanho
        tamanho_maximo = settings.VEROSSIMILHANCA_SETTINGS.get('MAX_FILE_SIZE', 10485760)
        if arquivo.size > tamanho_maximo:
            return False
        
        return True
    
    def _get_client_ip(self, request) -> str:
        """Obtém o IP do cliente."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class StatusProcessamentoView(View):
    """
    View para verificar status de processamento.
    
    Retorna informações sobre o progresso do processamento via AJAX.
    """
    
    def get(self, request, processamento_id):
        """Retorna status do processamento."""
        try:
            processamento = get_object_or_404(ProcessamentoArquivo, id=processamento_id)
            
            # Preparar dados de resposta
            data = {
                'id': processamento.id,
                'status': processamento.status,
                'nome_arquivo': processamento.nome_arquivo_original,
                'data_criacao': processamento.data_criacao.isoformat(),
                'total_itens': processamento.total_itens_processados,
                'total_baixas': processamento.total_similaridades_baixas,
                'limiar': processamento.limiar_similaridade,
                'tempo_processamento': processamento.tempo_processamento_segundos,
            }
            
            # Adicionar informações específicas por status
            if processamento.status == 'CONCLUIDO':
                data.update({
                    'percentual_baixas': processamento.percentual_similaridades_baixas,
                    'arquivo_disponivel': bool(processamento.arquivo_resultado),
                    'download_url': reverse('verossimilhanca:download', args=[processamento.id]) if processamento.arquivo_resultado else None
                })
            elif processamento.status == 'ERRO':
                data['mensagem_erro'] = processamento.mensagem_erro
            
            return JsonResponse(data)
            
        except Exception as e:
            logger.error(f"Erro ao verificar status: {str(e)}")
            return JsonResponse({
                'error': 'Erro ao verificar status do processamento'
            }, status=500)


class DownloadResultadoView(View):
    """
    View para download do arquivo de resultado.
    
    Permite baixar o arquivo Excel com os resultados da análise.
    """
    
    def get(self, request, processamento_id):
        """Faz download do arquivo de resultado."""
        try:
            processamento = get_object_or_404(ProcessamentoArquivo, id=processamento_id)
            
            # Verificar se o processamento foi concluído
            if processamento.status != 'CONCLUIDO':
                return JsonResponse({
                    'error': 'Processamento ainda não foi concluído'
                }, status=400)
            
            # Verificar se existe arquivo de resultado
            if not processamento.arquivo_resultado:
                return JsonResponse({
                    'error': 'Arquivo de resultado não encontrado'
                }, status=404)
            
            # Verificar se o arquivo existe fisicamente
            if not default_storage.exists(processamento.arquivo_resultado.name):
                return JsonResponse({
                    'error': 'Arquivo de resultado não encontrado no sistema'
                }, status=404)
            
            # Preparar resposta de download
            arquivo_path = processamento.arquivo_resultado.path
            
            response = FileResponse(
                open(arquivo_path, 'rb'),
                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            
            # Definir nome do arquivo para download
            nome_download = f"verossimilhanca_{processamento.id}_{settings.VEROSSIMILHANCA_SETTINGS.get('RESULT_FILENAME', 'resultados.xlsx')}"
            response['Content-Disposition'] = f'attachment; filename="{nome_download}"'
            
            logger.info(f"Download iniciado: Processamento {processamento.id}")
            
            return response
            
        except Exception as e:
            logger.error(f"Erro no download: {str(e)}")
            return JsonResponse({
                'error': 'Erro interno do servidor'
            }, status=500)


class HistoricoProcessamentosView(TemplateView):
    """
    View para exibir histórico de processamentos.
    
    Lista todos os processamentos realizados com informações resumidas.
    """
    
    template_name = 'verossimilhanca/historico.html'
    
    def get_context_data(self, **kwargs):
        """Adiciona dados de contexto para o template."""
        context = super().get_context_data(**kwargs)
        
        # Buscar processamentos (últimos 50)
        processamentos = ProcessamentoArquivo.objects.all()[:50]
        
        context.update({
            'processamentos': processamentos,
            'total_processamentos': ProcessamentoArquivo.objects.count(),
        })
        
        return context


class DetalhesProcessamentoView(TemplateView):
    """
    View para exibir detalhes de um processamento específico.
    
    Mostra informações detalhadas e resultados individuais.
    """
    
    template_name = 'verossimilhanca/detalhes.html'
    
    def get_context_data(self, **kwargs):
        """Adiciona dados de contexto para o template."""
        context = super().get_context_data(**kwargs)
        
        processamento_id = kwargs.get('processamento_id')
        processamento = get_object_or_404(ProcessamentoArquivo, id=processamento_id)
        
        # Buscar itens de similaridade
        itens = ItemSimilaridade.objects.filter(
            processamento=processamento
        ).order_by('similaridade')
        
        context.update({
            'processamento': processamento,
            'itens': itens,
            'total_itens': itens.count(),
        })
        
        return context


# API Views para integração externa

@csrf_exempt
@require_http_methods(["POST"])
def api_upload_arquivo(request):
    """
    API endpoint para upload de arquivo via POST.
    
    Aceita arquivos via multipart/form-data e retorna JSON com status.
    """
    try:
        if 'arquivo' not in request.FILES:
            return JsonResponse({
                'success': False,
                'message': 'Nenhum arquivo foi enviado'
            }, status=400)
        
        arquivo = request.FILES['arquivo']
        
        # Validar arquivo
        if not arquivo.name.lower().endswith('.xlsx'):
            return JsonResponse({
                'success': False,
                'message': 'Apenas arquivos .xlsx são aceitos'
            }, status=400)
        
        # Criar processamento
        processamento = ProcessamentoArquivo.objects.create(
            arquivo_original=arquivo,
            nome_arquivo_original=arquivo.name,
            tamanho_arquivo=arquivo.size,
            ip_usuario=request.META.get('REMOTE_ADDR', ''),
            user_agent=request.META.get('HTTP_USER_AGENT', ''),
        )
        
        # Iniciar processamento assíncrono
        thread = threading.Thread(
            target=processar_arquivo_async,
            args=(processamento.id,)
        )
        thread.daemon = True
        thread.start()
        
        return JsonResponse({
            'success': True,
            'message': 'Arquivo processado com sucesso',
            'processamento_id': processamento.id,
            'status_url': f'/api/status/{processamento.id}/',
            'download_url': f'/api/download/{processamento.id}/'
        })
        
    except Exception as e:
        logger.error(f"Erro na API de upload: {str(e)}")
        return JsonResponse({
            'success': False,
            'message': 'Erro interno do servidor'
        }, status=500)


@require_http_methods(["GET"])
def api_status_processamento(request, processamento_id):
    """
    API endpoint para verificar status de processamento.
    
    Retorna informações em formato JSON sobre o processamento.
    """
    try:
        processamento = get_object_or_404(ProcessamentoArquivo, id=processamento_id)
        
        data = {
            'id': processamento.id,
            'status': processamento.status,
            'nome_arquivo': processamento.nome_arquivo_original,
            'data_criacao': processamento.data_criacao.isoformat(),
            'total_itens': processamento.total_itens_processados,
            'total_baixas': processamento.total_similaridades_baixas,
            'percentual_baixas': processamento.percentual_similaridades_baixas,
            'tempo_processamento': processamento.tempo_processamento_segundos,
        }
        
        if processamento.status == 'CONCLUIDO' and processamento.arquivo_resultado:
            data['download_url'] = f'/api/download/{processamento.id}/'
        
        if processamento.status == 'ERRO':
            data['mensagem_erro'] = processamento.mensagem_erro
        
        return JsonResponse(data)
        
    except Exception as e:
        logger.error(f"Erro na API de status: {str(e)}")
        return JsonResponse({
            'error': 'Erro interno do servidor'
        }, status=500)


# Views auxiliares

def handler404(request, exception):
    """Handler personalizado para erro 404."""
    return render(request, 'verossimilhanca/404.html', status=404)


def handler500(request):
    """Handler personalizado para erro 500."""
    return render(request, 'verossimilhanca/500.html', status=500)
