from sentence_transformers import SentenceTransformer
import argparse
import numpy as np

# Carregar o modelo mais rápido (MiniLM)
model = SentenceTransformer("all-MiniLM-L6-v2")


# Função para calcular a similaridade entre dois textos
def compute_similarity(text1, text2):
    embeddings1 = model.encode([text1])  # Codificar o texto 1
    embeddings2 = model.encode([text2])  # Codificar o texto 2
    similarity_score = np.dot(
        embeddings1, embeddings2.T
    )  # Cálculo de similaridade (produto escalar)
    return similarity_score[0][0]


# Função para comparar dois textos de produtos
def compare_products(text1, text2):
    similarity_score = compute_similarity(text1, text2)
    result = f"Similaridade entre os produtos: {similarity_score:.4f}\n"

    # Salvar o resultado em um arquivo texto
    try:
        with open("resultado_comparacao.txt", "w") as file:
            file.write(result)
        print("Resultado salvo em 'resultado_comparacao.txt'.")
    except Exception as e:
        print(f"Erro ao salvar o arquivo: {e}")

    return result


# Função para lidar com argumentos de linha de comando
def main():
    # Usar argparse para lidar com a linha de comando
    parser = argparse.ArgumentParser(
        description="Compara dois textos descritivos de produtos."
    )
    parser.add_argument("text1", type=str, help="Texto 1 para comparação")
    parser.add_argument("text2", type=str, help="Texto 2 para comparação")

    args = parser.parse_args()

    # Comparar os textos e salvar o resultado
    compare_products(args.text1, args.text2)


if __name__ == "__main__":
    main()
