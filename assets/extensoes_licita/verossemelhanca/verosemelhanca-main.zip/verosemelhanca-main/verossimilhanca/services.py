"""
Serviços para o Sistema de Verificação de Verossimilhança.

Este módulo contém a lógica de negócio para processamento de arquivos Excel,
consulta às APIs externas e cálculo de similaridade usando modelos de linguagem.
"""

import os
import sys
import time
import json
import logging
import requests
import pandas as pd
import multiprocessing
import unicodedata
import re
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

# Importações para processamento de linguagem natural
try:
    from sentence_transformers import SentenceTransformer, models, util
    import nltk
    from nltk.stem import WordNetLemmatizer
    import unicodedata
    import re
    NLPTOOLS_AVAILABLE = True
except ImportError:
    NLPTOOLS_AVAILABLE = False

from .models import ProcessamentoArquivo, ItemSimilaridade

# Configurar logging
logger = logging.getLogger('verossimilhanca')


class VerossimilhancaService:
    """
    Serviço principal para processamento de verossimilhança.
    
    Coordena todo o fluxo de processamento desde o upload do arquivo
    até a geração do relatório final.
    """
    
    def __init__(self):
        """Inicializa o serviço com configurações padrão."""
        self.similarity_threshold = getattr(
            settings, 'VEROSSIMILHANCA_SETTINGS', {}
        ).get('SIMILARITY_THRESHOLD', 0.65)
        
        self.cnbs_api = CNBSAPIService()
        self.similarity_service = SimilarityService()
        
    def processar_arquivo(self, processamento_id: int) -> bool:
        """
        Processa um arquivo Excel completo.
        
        Args:
            processamento_id: ID do processamento no banco de dados
            
        Returns:
            bool: True se processado com sucesso, False caso contrário
        """
        try:
            # Buscar o processamento no banco
            processamento = ProcessamentoArquivo.objects.get(id=processamento_id)
            processamento.marcar_como_processando()
            
            logger.info(f"Iniciando processamento do arquivo: {processamento.nome_arquivo_original}")
            
            # Ler arquivo Excel
            df = self._ler_arquivo_excel(processamento.arquivo_original.path)
            if df is None:
                processamento.marcar_como_erro("Erro ao ler arquivo Excel")
                return False
            
            # Extrair dados do Excel
            linhas_originais, linhas_pesquisa = self._extrair_dados_excel(df)
            
            # Consultar API CNBS para cada item
            logger.info("Consultando API CNBS...")
            for linha in linhas_pesquisa:
                self.cnbs_api.buscar_dados_item(linha)
                self.cnbs_api.buscar_unidades_fornecimento(linha)
            
            # Preparar textos para comparação
            texto_original = self._preparar_texto_comparacao(linhas_originais)
            texto_cnbs = self._preparar_texto_comparacao(linhas_pesquisa)
            
            # Calcular similaridades
            logger.info("Calculando similaridades...")
            resultados = self.similarity_service.calcular_similaridades_lote(
                texto_original, texto_cnbs
            )
            
            # Filtrar resultados abaixo do limiar
            resultados_filtrados = [
                r for r in resultados if r[2] < self.similarity_threshold
            ]
            
            # Salvar resultados no banco
            self._salvar_resultados_banco(processamento, resultados_filtrados, linhas_originais)
            
            # Gerar arquivo Excel de resultado
            arquivo_resultado = self._gerar_arquivo_resultado(resultados_filtrados)
            
            # Finalizar processamento
            processamento.marcar_como_concluido(
                arquivo_resultado=arquivo_resultado,
                total_itens=len(resultados),
                total_baixas=len(resultados_filtrados)
            )
            
            logger.info(f"Processamento concluído: {len(resultados_filtrados)} itens com baixa similaridade")
            return True
            
        except Exception as e:
            logger.error(f"Erro no processamento: {str(e)}")
            try:
                processamento = ProcessamentoArquivo.objects.get(id=processamento_id)
                processamento.marcar_como_erro(str(e))
            except:
                pass
            return False
    
    def _ler_arquivo_excel(self, caminho_arquivo: str) -> Optional[pd.DataFrame]:
        """Lê arquivo Excel e retorna DataFrame."""
        try:
            return pd.read_excel(caminho_arquivo)
        except Exception as e:
            logger.error(f"Erro ao ler arquivo Excel: {str(e)}")
            return None
    
    def _extrair_dados_excel(self, df: pd.DataFrame) -> Tuple[List[Dict], List[Dict]]:
        """Extrai dados do DataFrame em formato adequado para processamento."""
        linhas_originais = []
        linhas_pesquisa = []
        
        for index, row in df.iterrows():
            # Linha original (com todas as informações)
            linha_original = {
                "index": row.get("Item", index),
                "catMat": row.get("Cód. SIASG", ""),
                "un": row.get("Un.", ""),
                "desc": str(row.get("Discriminação", "")).replace("\n", "")
            }
            linhas_originais.append(linha_original)
            
            # Linha para pesquisa (apenas código SIASG)
            linha_pesquisa = {
                "index": row.get("Item", index),
                "catMat": row.get("Cód. SIASG", "")
            }
            linhas_pesquisa.append(linha_pesquisa)
        
        return linhas_originais, linhas_pesquisa
    
    def _preparar_texto_comparacao(self, linhas: List[Dict]) -> str:
        """Prepara texto para comparação removendo padrões e normalizando."""
        processor = TextProcessor()
        texto_limpo = processor.remover_padroes(linhas)
        return texto_limpo
    
    def _salvar_resultados_banco(self, processamento: ProcessamentoArquivo, 
                                resultados: List[Tuple], linhas_originais: List[Dict]):
        """Salva resultados individuais no banco de dados."""
        for i, (original, comparada, similaridade, tempo) in enumerate(resultados):
            if i < len(linhas_originais):
                linha_original = linhas_originais[i]
                ItemSimilaridade.objects.create(
                    processamento=processamento,
                    codigo_siasg=linha_original.get('catMat', ''),
                    descricao_original=original,
                    descricao_cnbs=comparada,
                    similaridade=similaridade,
                    tempo_processamento=tempo,
                    unidade_original=linha_original.get('un', ''),
                    api_encontrada=bool(comparada.strip())
                )
    
    def _gerar_arquivo_resultado(self, resultados: List[Tuple]) -> ContentFile:
        """Gera arquivo Excel com os resultados."""
        df = pd.DataFrame(
            resultados,
            columns=["Frase Original", "Frase Comparada", "Similaridade", "Tempo (s)"]
        )
        
        # Salvar em buffer
        from io import BytesIO
        buffer = BytesIO()
        df.to_excel(buffer, index=False, engine='openpyxl')
        buffer.seek(0)
        
        # Criar ContentFile
        filename = settings.VEROSSIMILHANCA_SETTINGS.get('RESULT_FILENAME', 'resultados_menor.xlsx')
        return ContentFile(buffer.getvalue(), name=filename)


class CNBSAPIService:
    """
    Serviço para integração com a API do CNBS (Catálogo Nacional de Bens e Serviços).
    
    Responsável por consultar informações de itens e unidades de fornecimento.
    """
    
    def __init__(self):
        """Inicializa o serviço com URLs da API."""
        self.base_url = settings.CNBS_API_BASE_URL
        self.endpoints = settings.CNBS_API_ENDPOINTS
        
    def buscar_dados_item(self, linha: Dict) -> bool:
        """
        Busca dados de um item na API CNBS.
        
        Args:
            linha: Dicionário com dados do item (deve conter 'catMat')
            
        Returns:
            bool: True se encontrou dados, False caso contrário
        """
        try:
            # Limpar código SIASG
            codigo = str(linha["catMat"]).replace("BR", "")
            
            # Montar URL
            url = f"{self.base_url}{self.endpoints['item_material']}?codigo_item_material={codigo}"
            
            # Fazer requisição
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            json_item = response.json()
            
            # Extrair informações
            try:
                linha["desc"] = json_item["nomePdm"]
                valores = json_item.get("buscaItemCaracteristica", [])
                for valor in valores:
                    linha["desc"] += " " + str(valor.get("nomeValorCaracteristica", ""))
            except KeyError:
                linha["desc"] = "not found"
            
            try:
                linha["codPdm"] = json_item["codigoPdm"]
            except KeyError:
                linha["codPdm"] = "not found"
            
            return True
            
        except Exception as e:
            logger.warning(f"Erro ao buscar item {linha.get('catMat', '')}: {str(e)}")
            linha["desc"] = "not found"
            linha["codPdm"] = "not found"
            return False
    
    def buscar_unidades_fornecimento(self, linha: Dict) -> bool:
        """
        Busca unidades de fornecimento para um item.
        
        Args:
            linha: Dicionário com dados do item (deve conter 'codPdm')
            
        Returns:
            bool: True se encontrou unidades, False caso contrário
        """
        try:
            if linha.get("codPdm") == "not found":
                linha["unEncontradas"] = []
                linha["list_desc_sim"] = []
                linha["maior_sim"] = ""
                linha["valor_sim"] = 0
                return False
            
            # Montar URL
            url = f"{self.base_url}{self.endpoints['unidade_fornecimento']}?codigo_pdm={linha['codPdm']}"
            
            # Fazer requisição
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            unidades = response.json()
            
            # Processar unidades
            linha["unEncontradas"] = []
            for item in unidades:
                linha["unEncontradas"].append({
                    "sigla": item.get("siglaUnidadeFornecimento", ""),
                    "nome": item.get("nomeUnidadeFornecimento", ""),
                    "tamanho": item.get("capacidadeUnidadeMedida", ""),
                })
            
            # Preparar lista de descrições para similaridade
            list_desc_sim = []
            for un in linha.get("unEncontradas", []):
                dict_desc_sim = {
                    "desc": f"{un['nome']} {un['tamanho']}{un['sigla']}",
                    "sim": 0,
                }
                list_desc_sim.append(dict_desc_sim)
            
            linha["list_desc_sim"] = list_desc_sim
            linha["maior_sim"] = ""
            linha["valor_sim"] = 0
            
            # Remover codPdm para economizar memória
            if "codPdm" in linha:
                del linha["codPdm"]
            
            return True
            
        except Exception as e:
            logger.warning(f"Erro ao buscar unidades para {linha.get('codPdm', '')}: {str(e)}")
            linha["unEncontradas"] = []
            linha["list_desc_sim"] = []
            linha["maior_sim"] = ""
            linha["valor_sim"] = 0
            return False


class SimilarityService:
    """
    Serviço para cálculo de similaridade usando modelos de linguagem natural.
    
    Utiliza BERT português para calcular embeddings e similaridade de cosseno.
    """
    
    def __init__(self):
        """Inicializa o serviço carregando o modelo BERT."""
        self.model = None
        self._carregar_modelo()
    
    def _carregar_modelo(self):
        """Carrega o modelo BERT português."""
        if not NLPTOOLS_AVAILABLE:
            logger.error("Bibliotecas de NLP não disponíveis")
            return
        
        try:
            # Criar modelo BERT português manualmente
            word_embedding_model = models.Transformer("neuralmind/bert-base-portuguese-cased")
            pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension())
            self.model = SentenceTransformer(modules=[word_embedding_model, pooling_model])
            logger.info("Modelo BERT português carregado com sucesso")
        except Exception as e:
            logger.error(f"Erro ao carregar modelo BERT: {str(e)}")
    
    def calcular_similaridade(self, frase1: str, frase2: str) -> float:
        """
        Calcula similaridade entre duas frases.
        
        Args:
            frase1: Primeira frase
            frase2: Segunda frase
            
        Returns:
            float: Valor de similaridade entre 0 e 1
        """
        if not self.model:
            logger.warning("Modelo não disponível, retornando similaridade padrão")
            return 0.5
        
        try:
            # Obter embeddings
            embedding1 = self.model.encode(frase1, convert_to_tensor=True)
            embedding2 = self.model.encode(frase2, convert_to_tensor=True)
            
            # Calcular similaridade de cosseno
            similarity = util.cos_sim(embedding1, embedding2)
            
            return float(similarity[0][0])
            
        except Exception as e:
            logger.error(f"Erro ao calcular similaridade: {str(e)}")
            return 0.0
    
    def calcular_similaridades_lote(self, texto1: str, texto2: str) -> List[Tuple]:
        """
        Calcula similaridades para lotes de texto.
        
        Args:
            texto1: Texto com frases originais (separadas por quebra de linha)
            texto2: Texto com frases para comparação (separadas por quebra de linha)
            
        Returns:
            List[Tuple]: Lista de tuplas (frase1, frase2, similaridade, tempo)
        """
        # Dividir textos em linhas
        linhas1 = texto1.strip().split('\n')
        linhas2 = texto2.strip().split('\n')
        
        # Garantir mesmo número de linhas
        max_len = max(len(linhas1), len(linhas2))
        linhas1 += [''] * (max_len - len(linhas1))
        linhas2 += [''] * (max_len - len(linhas2))
        
        resultados = []
        
        for original, comparada in zip(linhas1, linhas2):
            inicio = time.time()
            similaridade = self.calcular_similaridade(original, comparada)
            tempo = time.time() - inicio
            
            resultados.append((original, comparada, similaridade, tempo))
        
        return resultados


class TextProcessor:
    """
    Processador de texto para normalização e limpeza.
    
    Remove padrões específicos, normaliza acentos e aplica lematização.
    """
    
    def __init__(self):
        """Inicializa o processador."""
        self.lemmatizer = None
        if NLPTOOLS_AVAILABLE:
            try:
                self.lemmatizer = WordNetLemmatizer()
            except:
                pass
    
    def normalize_text(self, text: str) -> str:
        """
        Normaliza texto removendo acentos e aplicando lematização.
        
        Args:
            text: Texto a ser normalizado
            
        Returns:
            str: Texto normalizado
        """
        # Remove acentos
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("utf-8")
        
        # Converte para minúsculas
        text = text.lower()
        
        # Remove caracteres não alfanuméricos
        text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
        
        # Lematização (se disponível)
        if self.lemmatizer:
            text = " ".join([self.lemmatizer.lemmatize(word) for word in text.split()])
        
        return text
    
    def remover_padroes(self, json_data: List[Dict]) -> str:
        """
        Remove padrões específicos dos textos e normaliza.
        
        Args:
            json_data: Lista de dicionários com campo 'desc'
            
        Returns:
            str: String concatenada com textos limpos
        """
        # Padrões a serem removidos
        patterns_to_remove = [
            "Função:",
            "Aplicação:",
            "Cor:",
            "Tipo:",
            "Aspecto Físico:",
            "Características adicionais:",
        ]
        
        # Normalizar padrões
        patterns_normalized = []
        for pattern in patterns_to_remove:
            pattern_norm = unicodedata.normalize("NFKD", pattern).encode("ascii", "ignore").decode("utf-8")
            pattern_norm = pattern_norm.lower()
            pattern_norm = re.sub(r"[^a-z\s]", "", pattern_norm)
            patterns_normalized.append(pattern_norm.strip())
        
        result = []
        
        for item in json_data:
            if "desc" in item:
                desc = item["desc"]
                desc = self.normalize_text(desc)
                
                # Remover padrões
                for pattern in patterns_normalized:
                    desc = re.sub(rf"{pattern}.*?(?=[A-Z]|$)", "", desc)
                
                # Limpar espaços extras
                desc = re.sub(r"\s{2,}", " ", desc).strip()
                
                # Normalizar novamente
                desc = self.normalize_text(desc)
                result.append(desc)
        
        return "\n".join(result)


def processar_arquivo_async(processamento_id: int):
    """
    Função para processamento assíncrono de arquivo.
    
    Args:
        processamento_id: ID do processamento no banco de dados
    """
    service = VerossimilhancaService()
    return service.processar_arquivo(processamento_id)
