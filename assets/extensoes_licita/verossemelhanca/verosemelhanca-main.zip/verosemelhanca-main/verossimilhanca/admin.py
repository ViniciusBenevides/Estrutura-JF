"""
Configuração do Django Admin para o Sistema de Verificação de Verossimilhança.

Este módulo configura a interface administrativa para gerenciar
processamentos, resultados e configurações do sistema.
"""

from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.db.models import Count, Avg
from django.utils import timezone
from datetime import timedelta

from .models import ProcessamentoArquivo, ItemSimilaridade, ConfiguracaoSistema


@admin.register(ProcessamentoArquivo)
class ProcessamentoArquivoAdmin(admin.ModelAdmin):
    """
    Configuração do admin para ProcessamentoArquivo.
    
    Permite visualizar, filtrar e gerenciar processamentos de arquivos.
    """
    
    list_display = [
        'id',
        'nome_arquivo_original',
        'status_colored',
        'usuario',
        'total_itens_processados',
        'total_similaridades_baixas',
        'percentual_baixas_display',
        'tempo_processamento_display',
        'data_criacao',
        'acoes'
    ]
    
    list_filter = [
        'status',
        'data_criacao',
        'data_inicio_processamento',
        'data_fim_processamento',
        'usuario',
    ]
    
    search_fields = [
        'nome_arquivo_original',
        'usuario__username',
        'ip_usuario',
    ]
    
    readonly_fields = [
        'data_criacao',
        'data_atualizacao',
        'data_inicio_processamento',
        'data_fim_processamento',
        'tempo_processamento_segundos',
        'duracao_processamento',
        'percentual_similaridades_baixas',
        'tamanho_arquivo',
        'ip_usuario',
        'user_agent',
    ]
    
    fieldsets = [
        ('Informações Básicas', {
            'fields': [
                'usuario',
                'nome_arquivo_original',
                'arquivo_original',
                'tamanho_arquivo',
                'status',
            ]
        }),
        ('Processamento', {
            'fields': [
                'limiar_similaridade',
                'data_inicio_processamento',
                'data_fim_processamento',
                'tempo_processamento_segundos',
                'duracao_processamento',
            ]
        }),
        ('Resultados', {
            'fields': [
                'total_itens_processados',
                'total_similaridades_baixas',
                'percentual_similaridades_baixas',
                'arquivo_resultado',
            ]
        }),
        ('Erro', {
            'fields': ['mensagem_erro'],
            'classes': ['collapse'],
        }),
        ('Metadados', {
            'fields': [
                'data_criacao',
                'data_atualizacao',
                'ip_usuario',
                'user_agent',
            ],
            'classes': ['collapse'],
        }),
    ]
    
    date_hierarchy = 'data_criacao'
    
    def status_colored(self, obj):
        """Exibe o status com cores."""
        colors = {
            'PENDENTE': '#ffc107',
            'PROCESSANDO': '#17a2b8',
            'CONCLUIDO': '#28a745',
            'ERRO': '#dc3545',
        }
        color = colors.get(obj.status, '#6c757d')
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            obj.get_status_display()
        )
    status_colored.short_description = 'Status'
    
    def percentual_baixas_display(self, obj):
        """Exibe o percentual de similaridades baixas."""
        if obj.total_itens_processados > 0:
            percentual = obj.percentual_similaridades_baixas
            return f"{percentual:.1f}%"
        return "-"
    percentual_baixas_display.short_description = 'Percentual Baixas'
    
    def tempo_processamento_display(self, obj):
        """Exibe o tempo de processamento formatado."""
        if obj.tempo_processamento_segundos:
            segundos = obj.tempo_processamento_segundos
            if segundos < 60:
                return f"{segundos:.1f}s"
            elif segundos < 3600:
                minutos = segundos / 60
                return f"{minutos:.1f}min"
            else:
                horas = segundos / 3600
                return f"{horas:.1f}h"
        return "-"
    tempo_processamento_display.short_description = 'Tempo'
    
    def acoes(self, obj):
        """Exibe links de ação."""
        links = []
        
        if obj.status == 'CONCLUIDO' and obj.arquivo_resultado:
            download_url = reverse('verossimilhanca:download', args=[obj.id])
            links.append(f'<a href="{download_url}" target="_blank">Download</a>')
        
        detalhes_url = reverse('admin:verossimilhanca_itemsimilaridade_changelist') + f'?processamento__id={obj.id}'
        links.append(f'<a href="{detalhes_url}">Ver Itens</a>')
        
        return mark_safe(' | '.join(links))
    acoes.short_description = 'Ações'
    
    def get_queryset(self, request):
        """Otimiza consultas."""
        return super().get_queryset(request).select_related('usuario')


@admin.register(ItemSimilaridade)
class ItemSimilaridadeAdmin(admin.ModelAdmin):
    """
    Configuração do admin para ItemSimilaridade.
    
    Permite visualizar resultados individuais de similaridade.
    """
    
    list_display = [
        'codigo_siasg',
        'processamento',
        'similaridade_display',
        'classificacao_similaridade',
        'tempo_processamento_display',
        'api_encontrada',
        'data_processamento',
    ]
    
    list_filter = [
        'api_encontrada',
        'data_processamento',
        'processamento__status',
    ]
    
    search_fields = [
        'codigo_siasg',
        'descricao_original',
        'descricao_cnbs',
        'processamento__nome_arquivo_original',
    ]
    
    readonly_fields = [
        'processamento',
        'data_processamento',
        'tempo_processamento',
        'similaridade_percentual',
        'classificacao_similaridade',
    ]
    
    fieldsets = [
        ('Identificação', {
            'fields': [
                'processamento',
                'codigo_siasg',
                'unidade_original',
                'codigo_pdm',
            ]
        }),
        ('Descrições', {
            'fields': [
                'descricao_original',
                'descricao_cnbs',
            ]
        }),
        ('Resultado', {
            'fields': [
                'similaridade',
                'similaridade_percentual',
                'classificacao_similaridade',
                'tempo_processamento',
                'api_encontrada',
            ]
        }),
        ('Metadados', {
            'fields': ['data_processamento'],
            'classes': ['collapse'],
        }),
    ]
    
    date_hierarchy = 'data_processamento'
    
    def similaridade_display(self, obj):
        """Exibe a similaridade formatada."""
        return f"{obj.similaridade:.4f}"
    similaridade_display.short_description = 'Similaridade'
    
    def tempo_processamento_display(self, obj):
        """Exibe o tempo de processamento formatado."""
        return f"{obj.tempo_processamento:.3f}s"
    tempo_processamento_display.short_description = 'Tempo'
    
    def get_queryset(self, request):
        """Otimiza consultas."""
        return super().get_queryset(request).select_related('processamento')


@admin.register(ConfiguracaoSistema)
class ConfiguracaoSistemaAdmin(admin.ModelAdmin):
    """
    Configuração do admin para ConfiguracaoSistema.
    
    Permite gerenciar configurações do sistema.
    """
    
    list_display = [
        'chave',
        'valor_truncado',
        'ativo',
        'data_criacao',
        'data_atualizacao',
    ]
    
    list_filter = [
        'ativo',
        'data_criacao',
        'data_atualizacao',
    ]
    
    search_fields = [
        'chave',
        'valor',
        'descricao',
    ]
    
    readonly_fields = [
        'data_criacao',
        'data_atualizacao',
    ]
    
    fieldsets = [
        ('Configuração', {
            'fields': [
                'chave',
                'valor',
                'descricao',
                'ativo',
            ]
        }),
        ('Metadados', {
            'fields': [
                'data_criacao',
                'data_atualizacao',
            ],
            'classes': ['collapse'],
        }),
    ]
    
    def valor_truncado(self, obj):
        """Exibe o valor truncado."""
        if len(obj.valor) > 50:
            return f"{obj.valor[:50]}..."
        return obj.valor
    valor_truncado.short_description = 'Valor'
