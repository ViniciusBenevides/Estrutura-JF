"""
URLs para o Sistema de Verificação de Verossimilhança.

Este módulo define as rotas da aplicação, mapeando URLs para views.
"""

from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

from . import views

app_name = 'verossimilhanca'

urlpatterns = [
    # Páginas principais
    path('', views.HomeView.as_view(), name='home'),
    path('historico/', views.HistoricoProcessamentosView.as_view(), name='historico'),
    path('detalhes/<int:processamento_id>/', views.DetalhesProcessamentoView.as_view(), name='detalhes'),
    
    # Funcionalidades de processamento
    path('upload/', views.UploadArquivoView.as_view(), name='upload'),
    path('status/<int:processamento_id>/', views.StatusProcessamentoView.as_view(), name='status'),
    path('download/<int:processamento_id>/', views.DownloadResultadoView.as_view(), name='download'),
    
    # API endpoints
    path('api/upload/', views.api_upload_arquivo, name='api_upload'),
    path('api/status/<int:processamento_id>/', views.api_status_processamento, name='api_status'),
]

# Servir arquivos de media em desenvolvimento
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
