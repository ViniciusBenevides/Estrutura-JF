from sentence_transformers import SentenceTransformer, models, util
import multiprocessing
import time
import requests
import pandas as pd
import json
import re
import unicodedata
from nltk.stem import WordNetLemmatizer
import nltk

# Baixar os recursos necessários
# nltk.download('wordnet')
# nltk.download('omw-1.4')

lemmatizer = WordNetLemmatizer()


def criar_modelo_bert_portuguese():
    """
    Cria uma pipeline manualmente para usar o modelo 'neuralmind/bert-base-portuguese-cased'
    como um SentenceTransformer.
    """
    # Carregar o modelo Transformer (backbone)
    word_embedding_model = models.Transformer("neuralmind/bert-base-portuguese-cased")

    # Adicionar a camada de pooling para transformar embeddings de tokens em embeddings de sentenças
    pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension())

    # Criar o modelo SentenceTransformer
    return SentenceTransformer(modules=[word_embedding_model, pooling_model])


def calcular_similaridade_bert(frase1: str, frase2: str, model) -> float:
    """
    Usa um modelo BERT-like (via Sentence Transformers) para calcular
    embeddings das frases e então retorna a similaridade de cosseno.
    Retorna valor entre 0 e 1.
    """
    # Obter embeddings
    embedding1 = model.encode(frase1, convert_to_tensor=True)
    embedding2 = model.encode(frase2, convert_to_tensor=True)

    # Calcular similaridade de cosseno
    similarity = util.cos_sim(embedding1, embedding2)

    # O retorno de cos_sim() é um tensor 1x1, então pegamos o item.
    return float(similarity[0][0])


def ler_frases_do_arquivo(nome_arquivo: str, delimitador: str = "\t") -> list:
    """
    Lê frases de um arquivo texto, onde cada linha contém um par de frases
    separadas por um delimitador.
    Retorna uma lista de pares de frases.
    """
    pares_de_frases = []
    with open(nome_arquivo, "r", encoding="utf-8") as file:
        for linha in file:
            # Remover espaços e quebras de linha
            linha = linha.strip()
            if delimitador in linha:
                # Dividir a linha em duas frases com base no delimitador
                partes = linha.split(delimitador, 1)
                if len(partes) == 2:
                    pares_de_frases.append((partes[0].strip(), partes[1].strip()))
    return pares_de_frases


def make_request_item(linha):
    link_base_item = (
        "https://cnbs.estaleiro.serpro.gov.br/cnbs-api/material/v1/recuperaDadosItemMaterialPorCodigo"
        "?codigo_item_material="
    )

    if "BR" in str(linha["catMat"]):
        linha["catMat"] = str(linha["catMat"]).replace("BR", "")
    try:
        response = requests.get(link_base_item + str(linha["catMat"]))
        json_item = response.json()
        # erros devem ser trabalhados para o caso de não encontrar um catMat
    except Exception as e:
        raise e
    try:
        linha["desc"] = json_item["nomePdm"]
        valores = json_item["buscaItemCaracteristica"]
        for valor in valores:
            linha["desc"] += " " + str(valor["nomeValorCaracteristica"])
    except KeyError:
        linha["desc"] = "not found"
    try:
        linha["codPdm"] = json_item[
            "codigoPdm"
        ]  # valor utilizado para montar o proximo link
    except KeyError:
        linha["codPdm"] = "not found"


def make_request_unidades(linha):
    link_base_unidades = (
        "https://cnbs.estaleiro.serpro.gov.br/cnbs-api/material/v1/unidadeFornecimentoPorCodigoPdm"
        "?codigo_pdm="
    )
    if (
        linha["codPdm"] != "not found"
    ):  # garantir que haja um codigo a pesquisar no request
        linha["unEncontradas"] = []
        response = requests.get(link_base_unidades + str(linha["codPdm"]))
        unidades = response.json()
        for item in unidades:  # manipulação de json. cada unidade descoberta tem esses campos que nos interessam
            linha["unEncontradas"].append(
                {
                    "sigla": item["siglaUnidadeFornecimento"],
                    "nome": item["nomeUnidadeFornecimento"],
                    "tamanho": item["capacidadeUnidadeMedida"],
                }
            )
        del linha["codPdm"]

    list_desc_sim = []
    for un in linha.get("unEncontradas"):
        dict_desc_sim = {
            "desc": un["nome"] + " " + str(un["tamanho"]) + str(un["sigla"]),
            "sim": 0,
        }
        list_desc_sim.append(dict_desc_sim.copy())

    linha["list_desc_sim"] = list_desc_sim
    linha["maior_sim"] = ""
    linha["valor_sim"] = 0


def normalize_text(text):
    """
    Normaliza o texto removendo acentos, convertendo para letras minúsculas,
    removendo caracteres não alfanuméricos e aplicando lematização.

    Args:
        text (str): O texto a ser normalizado.

    Returns:
        str: Texto normalizado e lematizado.
    """
    # Remove os acentos
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("utf-8")
    # Converte para minúsculas
    text = text.lower()
    # Remove caracteres que não sejam letras ou números
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    # Lematiza cada palavra
    text = " ".join([lemmatizer.lemmatize(word) for word in text.split()])
    return text


def normalize_patterns(patterns):
    """
    Normaliza uma lista de padrões, removendo acentos, convertendo para minúsculas
    e mantendo apenas caracteres alfabéticos e espaços.

    Args:
        patterns (list): Lista de padrões a serem normalizados.

    Returns:
        list: Lista de padrões normalizados.
    """
    normalized_patterns = []
    for pattern in patterns:
        # Remove acentos
        pattern = (
            unicodedata.normalize("NFKD", pattern)
            .encode("ascii", "ignore")
            .decode("utf-8")
        )
        # Converte para minúsculas
        pattern = pattern.lower()
        # Remove caracteres não alfabéticos ou espaço
        pattern = re.sub(r"[^a-z\s]", "", pattern)
        # Adiciona o padrão normalizado à lista
        normalized_patterns.append(pattern.strip())
    return normalized_patterns


def remover_padroes(json_data):
    """
    Processa um JSON para remover padrões específicos do campo 'desc', normaliza o texto,
    lematiza e retorna uma string concatenada com os valores limpos de 'desc' de cada linha.

    Args:
        json_data (list): Lista contendo os dicionários com o campo 'desc'.

    Returns:
        str: String concatenada com os valores limpos de 'desc'.
    """
    # Padrões a serem removidos
    patterns_to_remove = [
        "Função:",
        "Aplicação:",
        "Cor:",
        "Tipo:",
        "Aspecto Físico:",
        "Características adicionais:",
    ]

    patterns_to_remove = normalize_patterns(patterns_to_remove)

    result = []

    for item in json_data:
        if "desc" in item:
            desc = item["desc"]
            desc = normalize_text(desc)
            # Remover os padrões
            for pattern in patterns_to_remove:
                desc = re.sub(rf"{pattern}.*?(?=[A-Z]|$)", "", desc)
            # Limpar espaços extras
            desc = re.sub(r"\s{2,}", " ", desc).strip()
            # Normalizar o texto (remover acentos, lematizar e limpar)
            desc = normalize_text(desc)
            result.append(desc)

    # Retornar como string única separada por quebra de linha
    return "\n".join(result)


def combine_and_save_lines(string1, string2, output_file="frases.txt"):
    """
    Combina linhas de duas strings, separadas por tab, e grava em um arquivo de texto.

    Args:
        string1 (str): Primeira string com várias linhas.
        string2 (str): Segunda string com várias linhas.
        output_file (str): Nome do arquivo de saída. Default é "frases.txt".
    """
    # Quebrar as strings em listas de linhas
    lines1 = string1.strip().split("\n")
    lines2 = string2.strip().split("\n")

    # Garantir que ambas tenham o mesmo número de linhas
    max_len = max(len(lines1), len(lines2))
    lines1 += [""] * (max_len - len(lines1))
    lines2 += [""] * (max_len - len(lines2))

    # Combinar as linhas com tab
    combined_lines = [f"{line1}\t{line2}" for line1, line2 in zip(lines1, lines2)]

    # Gravar no arquivo
    with open(output_file, "w", encoding="utf-8") as file:
        file.write("\n".join(combined_lines))


def salvar_similaridade_menor_percentual(
    matriz_resultados, arquivo_excel="resultados_menor.xlsx", percentual=0.7
):
    """
    Salva os pares de frases e valores de similaridade menores que 70% em um arquivo Excel.

    Args:
        matriz_resultados (list): Lista de tuplas contendo as frases originais, comparadas e a similaridade.
        arquivo_excel (str): Nome do arquivo Excel a ser salvo.
    """
    # Filtrar os resultados com similaridade < 70%
    filtrados = [
        resultado for resultado in matriz_resultados if resultado[2] < percentual
    ]

    # Criar DataFrame
    df = pd.DataFrame(
        filtrados,
        columns=["Frase Original", "Frase Comparada", "Similaridade", "Tempo (s)"],
    )

    # Salvar no Excel
    df.to_excel(arquivo_excel, index=False)
    print(
        f"Arquivo Excel '{arquivo_excel}' salvo com sucesso com {len(filtrados)} pares de frases!"
    )


def main():
    # Medir tempo de execução total
    inicio_total = time.time()

    # -------------------------- extrair codigos do xlsx ---------------------
    caminho_arquivo = r"pam_101.xlsx"

    df = pd.read_excel(caminho_arquivo)

    linhas_originais = []  # o vetor de linhas vindo do excel original
    linhas_pesquisadas = []  # vetor pesquisado no site

    # Percorrer as linhas do DataFrame e adicionar os valores de cada linha a lista
    for index, row in df.iterrows():
        linha = {"index": row["Item"], "catMat": row["Cód. SIASG"]}
        linhas_pesquisadas.append(
            linha.copy()
        )  # a partir daqui os vetores se diferenciam
        linha["un"] = row["Un."]
        linha["desc"] = str(row["Discriminação"]).replace("\n", "")
        linhas_originais.append(linha.copy())

    # --------------------------- fazer as requisições ------------------------
    for linha in linhas_pesquisadas:
        make_request_item(linha)

    for linha in linhas_pesquisadas:
        make_request_unidades(linha)

    linha01 = remover_padroes(linhas_originais)
    linha02 = remover_padroes(linhas_pesquisadas)

    combine_and_save_lines(linha01, linha02)

    # Criar o modelo
    model = criar_modelo_bert_portuguese()

    # Nome do arquivo com as frases
    nome_arquivo = "frases.txt"  # Substitua pelo nome do arquivo

    # Ler as frases do arquivo
    matriz_frases = ler_frases_do_arquivo(nome_arquivo, delimitador="\t")

    # Validação da matriz_frases
    if not matriz_frases:
        print("O arquivo não contém pares válidos de frases.")
        return

    # Lista para armazenar os resultados
    resultados_similaridade = []

    # Processar cada par de frases e calcular similaridade
    for original, comparada in matriz_frases:
        inicio_par = time.time()
        similaridade = calcular_similaridade_bert(original, comparada, model)
        fim_par = time.time()
        tempo_por_par = fim_par - inicio_par

        # Armazena o resultado
        resultados_similaridade.append(
            (original, comparada, similaridade, tempo_por_par)
        )

    salvar_similaridade_menor_percentual(resultados_similaridade, percentual=0.65)
    # Medir tempo final e calcular a duração total
    fim_total = time.time()
    duracao_total = fim_total - inicio_total
    # print(f"\nTempo total de execução: {duracao_total:.2f} segundos")


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")  # Necessário no Windows
    main()
