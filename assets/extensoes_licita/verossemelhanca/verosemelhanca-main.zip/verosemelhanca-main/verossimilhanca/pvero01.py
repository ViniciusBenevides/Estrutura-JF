import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer
import argparse

# Carregar o modelo e tokenizer
model_name = "distilbert-base-uncased"  # Modelo pré-treinado (distilbert, por exemplo)
model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=1)
tokenizer = AutoTokenizer.from_pretrained(model_name)


# Função para pré-processar os textos
def preprocess_texts(text1, text2):
    # Tokenizar os pares de texto
    return tokenizer(text1, text2, return_tensors="pt", padding=True, truncation=True)


# Função para calcular a similaridade
def compute_similarity(text1, text2):
    inputs = preprocess_texts(text1, text2)
    with torch.no_grad():
        outputs = model(**inputs)
        similarity_score = outputs.logits.item()  # Valor de similaridade entre 0 e 1
    return similarity_score


# Função para comparar dois textos de produtos
def compare_products(text1, text2):
    similarity_score = compute_similarity(text1, text2)
    result = f"Similaridade entre os produtos: {similarity_score:.4f}\n"

    # Salvar o resultado em um arquivo texto
    try:
        with open("resultado_comparacao.txt", "w") as file:
            file.write(result)
        print("Resultado salvo em 'resultado_comparacao.txt'.")
    except Exception as e:
        print(f"Erro ao salvar o arquivo: {e}")

    return result


# Função para lidar com argumentos de linha de comando
def main():
    # Usar argparse para lidar com a linha de comando
    parser = argparse.ArgumentParser(
        description="Compara dois textos descritivos de produtos."
    )
    parser.add_argument("text1", type=str, help="Texto 1 para comparação")
    parser.add_argument("text2", type=str, help="Texto 2 para comparação")

    args = parser.parse_args()

    # Comparar os textos e salvar o resultado
    compare_products(args.text1, args.text2)


if __name__ == "__main__":
    main()
