"""
Modelos Django para o Sistema de Verificação de Verossimilhança.

Este módulo define os modelos de dados para armazenar informações sobre
processamentos de arquivos Excel e resultados de análise de similaridade.
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import os


class ProcessamentoArquivo(models.Model):
    """
    Modelo para armazenar informações sobre processamentos de arquivos Excel.
    
    Registra cada upload e processamento realizado no sistema, incluindo
    metadados do arquivo, status do processamento e resultados.
    """
    
    STATUS_CHOICES = [
        ('PENDENTE', 'Pendente'),
        ('PROCESSANDO', 'Processando'),
        ('CONCLUIDO', 'Concluído'),
        ('ERRO', 'Erro'),
    ]
    
    # Informações básicas do processamento
    usuario = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        null=True, 
        blank=True,
        verbose_name='Usuário',
        help_text='Usuário que iniciou o processamento'
    )
    
    data_criacao = models.DateTimeField(
        default=timezone.now,
        verbose_name='Data de Criação',
        help_text='Data e hora do upload do arquivo'
    )
    
    data_atualizacao = models.DateTimeField(
        auto_now=True,
        verbose_name='Data de Atualização',
        help_text='Data e hora da última atualização'
    )
    
    # Informações do arquivo
    arquivo_original = models.FileField(
        upload_to='uploads/',
        verbose_name='Arquivo Original',
        help_text='Arquivo Excel enviado para processamento'
    )
    
    nome_arquivo_original = models.CharField(
        max_length=255,
        verbose_name='Nome do Arquivo Original',
        help_text='Nome original do arquivo enviado'
    )
    
    tamanho_arquivo = models.PositiveIntegerField(
        verbose_name='Tamanho do Arquivo (bytes)',
        help_text='Tamanho do arquivo em bytes'
    )
    
    # Status e controle do processamento
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='PENDENTE',
        verbose_name='Status',
        help_text='Status atual do processamento'
    )
    
    data_inicio_processamento = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='Início do Processamento',
        help_text='Data e hora do início do processamento'
    )
    
    data_fim_processamento = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='Fim do Processamento',
        help_text='Data e hora da conclusão do processamento'
    )
    
    # Resultados do processamento
    arquivo_resultado = models.FileField(
        upload_to='downloads/',
        null=True,
        blank=True,
        verbose_name='Arquivo de Resultado',
        help_text='Arquivo Excel com os resultados da análise'
    )
    
    total_itens_processados = models.PositiveIntegerField(
        default=0,
        verbose_name='Total de Itens Processados',
        help_text='Número total de itens processados do arquivo'
    )
    
    total_similaridades_baixas = models.PositiveIntegerField(
        default=0,
        verbose_name='Total de Similaridades Baixas',
        help_text='Número de itens com similaridade abaixo do limiar'
    )
    
    limiar_similaridade = models.FloatField(
        default=0.65,
        verbose_name='Limiar de Similaridade',
        help_text='Valor do limiar usado para filtrar resultados (0.0 a 1.0)'
    )
    
    # Informações de erro
    mensagem_erro = models.TextField(
        null=True,
        blank=True,
        verbose_name='Mensagem de Erro',
        help_text='Detalhes do erro caso o processamento falhe'
    )
    
    # Metadados adicionais
    tempo_processamento_segundos = models.FloatField(
        null=True,
        blank=True,
        verbose_name='Tempo de Processamento (segundos)',
        help_text='Tempo total gasto no processamento'
    )
    
    ip_usuario = models.GenericIPAddressField(
        null=True,
        blank=True,
        verbose_name='IP do Usuário',
        help_text='Endereço IP do usuário que fez o upload'
    )
    
    user_agent = models.TextField(
        null=True,
        blank=True,
        verbose_name='User Agent',
        help_text='Informações do navegador do usuário'
    )
    
    class Meta:
        verbose_name = 'Processamento de Arquivo'
        verbose_name_plural = 'Processamentos de Arquivos'
        ordering = ['-data_criacao']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['data_criacao']),
            models.Index(fields=['usuario']),
        ]
    
    def __str__(self):
        return f"{self.nome_arquivo_original} - {self.status} ({self.data_criacao.strftime('%d/%m/%Y %H:%M')})"
    
    @property
    def duracao_processamento(self):
        """Retorna a duração do processamento em segundos."""
        if self.data_inicio_processamento and self.data_fim_processamento:
            delta = self.data_fim_processamento - self.data_inicio_processamento
            return delta.total_seconds()
        return None
    
    @property
    def percentual_similaridades_baixas(self):
        """Retorna o percentual de itens com similaridade baixa."""
        if self.total_itens_processados > 0:
            return (self.total_similaridades_baixas / self.total_itens_processados) * 100
        return 0
    
    def marcar_como_processando(self):
        """Marca o processamento como em andamento."""
        self.status = 'PROCESSANDO'
        self.data_inicio_processamento = timezone.now()
        self.save(update_fields=['status', 'data_inicio_processamento'])
    
    def marcar_como_concluido(self, arquivo_resultado=None, total_itens=0, total_baixas=0):
        """Marca o processamento como concluído."""
        self.status = 'CONCLUIDO'
        self.data_fim_processamento = timezone.now()
        if arquivo_resultado:
            self.arquivo_resultado = arquivo_resultado
        self.total_itens_processados = total_itens
        self.total_similaridades_baixas = total_baixas
        if self.data_inicio_processamento:
            self.tempo_processamento_segundos = self.duracao_processamento
        self.save()
    
    def marcar_como_erro(self, mensagem_erro):
        """Marca o processamento como erro."""
        self.status = 'ERRO'
        self.data_fim_processamento = timezone.now()
        self.mensagem_erro = mensagem_erro
        if self.data_inicio_processamento:
            self.tempo_processamento_segundos = self.duracao_processamento
        self.save()


class ItemSimilaridade(models.Model):
    """
    Modelo para armazenar resultados individuais de similaridade.
    
    Cada registro representa a comparação entre uma descrição original
    e uma descrição obtida da API CNBS, com o valor de similaridade calculado.
    """
    
    processamento = models.ForeignKey(
        ProcessamentoArquivo,
        on_delete=models.CASCADE,
        related_name='itens_similaridade',
        verbose_name='Processamento',
        help_text='Processamento ao qual este item pertence'
    )
    
    # Dados do item original
    codigo_siasg = models.CharField(
        max_length=20,
        verbose_name='Código SIASG',
        help_text='Código SIASG do item'
    )
    
    descricao_original = models.TextField(
        verbose_name='Descrição Original',
        help_text='Descrição original do item no arquivo Excel'
    )
    
    unidade_original = models.CharField(
        max_length=10,
        null=True,
        blank=True,
        verbose_name='Unidade Original',
        help_text='Unidade de medida original do item'
    )
    
    # Dados obtidos da API CNBS
    descricao_cnbs = models.TextField(
        null=True,
        blank=True,
        verbose_name='Descrição CNBS',
        help_text='Descrição obtida da API do CNBS'
    )
    
    codigo_pdm = models.CharField(
        max_length=20,
        null=True,
        blank=True,
        verbose_name='Código PDM',
        help_text='Código PDM obtido da API'
    )
    
    # Resultado da análise
    similaridade = models.FloatField(
        verbose_name='Similaridade',
        help_text='Valor de similaridade calculado (0.0 a 1.0)'
    )
    
    tempo_processamento = models.FloatField(
        verbose_name='Tempo de Processamento (segundos)',
        help_text='Tempo gasto para processar este item'
    )
    
    # Metadados
    data_processamento = models.DateTimeField(
        default=timezone.now,
        verbose_name='Data do Processamento',
        help_text='Data e hora do processamento deste item'
    )
    
    api_encontrada = models.BooleanField(
        default=True,
        verbose_name='API Encontrada',
        help_text='Indica se o item foi encontrado na API do CNBS'
    )
    
    class Meta:
        verbose_name = 'Item de Similaridade'
        verbose_name_plural = 'Itens de Similaridade'
        ordering = ['processamento', 'codigo_siasg']
        indexes = [
            models.Index(fields=['processamento', 'similaridade']),
            models.Index(fields=['codigo_siasg']),
            models.Index(fields=['similaridade']),
        ]
    
    def __str__(self):
        return f"{self.codigo_siasg} - Similaridade: {self.similaridade:.4f}"
    
    @property
    def similaridade_percentual(self):
        """Retorna a similaridade em formato percentual."""
        return self.similaridade * 100
    
    @property
    def classificacao_similaridade(self):
        """Retorna uma classificação textual da similaridade."""
        if self.similaridade >= 0.9:
            return 'Muito Alta'
        elif self.similaridade >= 0.75:
            return 'Alta'
        elif self.similaridade >= 0.5:
            return 'Média'
        elif self.similaridade >= 0.25:
            return 'Baixa'
        else:
            return 'Muito Baixa'


class ConfiguracaoSistema(models.Model):
    """
    Modelo para armazenar configurações do sistema.
    
    Permite ajustar parâmetros do sistema sem necessidade de alteração no código.
    """
    
    chave = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='Chave',
        help_text='Identificador único da configuração'
    )
    
    valor = models.TextField(
        verbose_name='Valor',
        help_text='Valor da configuração'
    )
    
    descricao = models.TextField(
        null=True,
        blank=True,
        verbose_name='Descrição',
        help_text='Descrição da configuração'
    )
    
    data_criacao = models.DateTimeField(
        default=timezone.now,
        verbose_name='Data de Criação'
    )
    
    data_atualizacao = models.DateTimeField(
        auto_now=True,
        verbose_name='Data de Atualização'
    )
    
    ativo = models.BooleanField(
        default=True,
        verbose_name='Ativo',
        help_text='Indica se a configuração está ativa'
    )
    
    class Meta:
        verbose_name = 'Configuração do Sistema'
        verbose_name_plural = 'Configurações do Sistema'
        ordering = ['chave']
    
    def __str__(self):
        return f"{self.chave}: {self.valor[:50]}{'...' if len(self.valor) > 50 else ''}"
    
    @classmethod
    def get_valor(cls, chave, default=None):
        """Obtém o valor de uma configuração."""
        try:
            config = cls.objects.get(chave=chave, ativo=True)
            return config.valor
        except cls.DoesNotExist:
            return default
    
    @classmethod
    def set_valor(cls, chave, valor, descricao=None):
        """Define o valor de uma configuração."""
        config, created = cls.objects.get_or_create(
            chave=chave,
            defaults={'valor': valor, 'descricao': descricao}
        )
        if not created:
            config.valor = valor
            if descricao:
                config.descricao = descricao
            config.save()
        return config
