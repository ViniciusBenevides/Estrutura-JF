#!/usr/bin/env python3
"""
Script de teste básico para o Sistema de Verificação de Verossimilhança.

Este script valida as funcionalidades principais do sistema Django
sem necessidade de bibliotecas de NLP pesadas.
"""

import os
import sys
import django
from pathlib import Path

# Configurar Django
sys.path.append(str(Path(__file__).parent))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'verossimilhanca_project.settings')
django.setup()

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from verossimilhanca.models import ProcessamentoArquivo, ItemSimilaridade, ConfiguracaoSistema


def test_models():
    """Testa a criação e funcionamento dos modelos."""
    print("🧪 Testando modelos...")
    
    # Criar usuário de teste
    user, created = User.objects.get_or_create(
        username='testuser',
        defaults={'email': 'test@example.com'}
    )
    if created:
        user.set_password('testpass')
        user.save()
    
    # Testar ProcessamentoArquivo
    processamento = ProcessamentoArquivo.objects.create(
        usuario=user,
        nome_arquivo_original='teste.xlsx',
        tamanho_arquivo=1024,
        ip_usuario='127.0.0.1',
        user_agent='Test Browser'
    )
    
    assert processamento.status == 'PENDENTE'
    assert processamento.percentual_similaridades_baixas == 0
    
    # Testar mudança de status
    processamento.marcar_como_processando()
    assert processamento.status == 'PROCESSANDO'
    
    processamento.marcar_como_concluido(total_itens=10, total_baixas=3)
    assert processamento.status == 'CONCLUIDO'
    assert processamento.total_itens_processados == 10
    assert processamento.total_similaridades_baixas == 3
    assert processamento.percentual_similaridades_baixas == 30.0
    
    # Testar ItemSimilaridade
    item = ItemSimilaridade.objects.create(
        processamento=processamento,
        codigo_siasg='12345',
        descricao_original='Produto teste',
        descricao_cnbs='Produto similar',
        similaridade=0.45,
        tempo_processamento=1.5
    )
    
    assert item.similaridade_percentual == 45.0
    assert item.classificacao_similaridade == 'Baixa'
    
    # Testar ConfiguracaoSistema
    config, created = ConfiguracaoSistema.objects.get_or_create(
        chave='teste_config',
        defaults={
            'valor': 'valor_teste',
            'descricao': 'Configuração de teste'
        }
    )
    
    assert ConfiguracaoSistema.get_valor('teste_config') == 'valor_teste'
    assert ConfiguracaoSistema.get_valor('inexistente', 'default') == 'default'
    
    print("✅ Modelos testados com sucesso!")


def test_views():
    """Testa as views principais."""
    print("🧪 Testando views...")
    
    client = Client()
    
    # Testar página inicial
    response = client.get('/')
    assert response.status_code == 200
    assert 'Verificar Verossimilhança' in response.content.decode()
    
    # Testar página de histórico
    response = client.get('/historico/')
    assert response.status_code == 200
    
    # Testar API de status (deve retornar erro para ID inexistente)
    response = client.get('/status/999/')
    assert response.status_code in [404, 500]  # Pode ser 404 ou 500 dependendo da implementação
    
    print("✅ Views testadas com sucesso!")


def test_admin():
    """Testa se o admin está configurado corretamente."""
    print("🧪 Testando admin...")
    
    client = Client()
    
    # Testar acesso ao admin (deve redirecionar para login)
    response = client.get('/admin/')
    assert response.status_code == 302
    
    # Fazer login como admin
    admin_user = User.objects.filter(is_superuser=True).first()
    if admin_user:
        client.force_login(admin_user)
        response = client.get('/admin/')
        assert response.status_code == 200
        assert 'Verossimilhança' in response.content.decode()
    
    print("✅ Admin testado com sucesso!")


def test_services():
    """Testa os serviços básicos (sem NLP)."""
    print("🧪 Testando serviços...")
    
    from verossimilhanca.services import TextProcessor, CNBSAPIService
    
    # Testar TextProcessor
    processor = TextProcessor()
    
    # Testar normalização de texto
    texto_original = "Função: Teste Aplicação: Sistema"
    texto_normalizado = processor.normalize_text(texto_original)
    assert len(texto_normalizado) > 0
    assert texto_normalizado.islower()
    
    # Testar remoção de padrões
    dados_teste = [
        {"desc": "Função: Limpeza Aplicação: Escritório Cor: Azul"},
        {"desc": "Tipo: Material Aspecto Físico: Sólido"}
    ]
    
    resultado = processor.remover_padroes(dados_teste)
    assert isinstance(resultado, str)
    assert len(resultado) > 0
    
    print("✅ Serviços testados com sucesso!")


def test_settings():
    """Testa as configurações do Django."""
    print("🧪 Testando configurações...")
    
    from django.conf import settings
    
    # Verificar configurações básicas
    assert settings.DEBUG == True
    assert 'verossimilhanca' in settings.INSTALLED_APPS
    assert settings.LANGUAGE_CODE == 'pt-br'
    assert settings.TIME_ZONE == 'America/Sao_Paulo'
    
    # Verificar configurações específicas
    assert 'VEROSSIMILHANCA_SETTINGS' in dir(settings)
    assert settings.VEROSSIMILHANCA_SETTINGS['SIMILARITY_THRESHOLD'] == 0.65
    
    print("✅ Configurações testadas com sucesso!")


def main():
    """Executa todos os testes."""
    print("🚀 Iniciando testes do Sistema de Verificação de Verossimilhança")
    print("=" * 60)
    
    try:
        test_settings()
        test_models()
        test_views()
        test_admin()
        test_services()
        
        print("=" * 60)
        print("🎉 Todos os testes passaram com sucesso!")
        print("✅ Sistema Django está funcionando corretamente")
        
        return True
        
    except Exception as e:
        print("=" * 60)
        print(f"❌ Erro nos testes: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
