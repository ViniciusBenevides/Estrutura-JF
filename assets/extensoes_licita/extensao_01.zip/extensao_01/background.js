chrome.action.onClicked.addListener(async (tab) => {
    try {
      console.log("Extensão acionada. Iniciando captura...");
  
      // Certifique-se de que há uma aba ativa
      if (!tab || !tab.id) {
        console.error("Erro: Nenhuma aba ativa encontrada.");
        return;
      }
  
      // Obter dimensões da página
      const dimensions = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const body = document.body;
          const html = document.documentElement;
          return {
            width: Math.max(body.scrollWidth, html.scrollWidth),
            height: Math.max(body.scrollHeight, html.scrollHeight),
            devicePixelRatio: window.devicePixelRatio,
            viewportHeight: window.innerHeight,
          };
        },
      });
  
      if (!dimensions || dimensions.length === 0) {
        console.error("Falha ao obter dimensões da página.");
        return;
      }
  
      const { width, height, devicePixelRatio, viewportHeight } = dimensions[0].result;
  
      console.log("Dimensões da página:", width, height, "DPR:", devicePixelRatio);
  
      const capturedImages = [];
  
      for (let y = 0; y < height; y += viewportHeight) {
        console.log(`Capturando parte da página na posição Y: ${y}`);
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (scrollY) => window.scrollTo(0, scrollY),
          args: [y],
        });
  
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
          format: "png",
        });
  
        capturedImages.push(dataUrl);
        console.log(`Captura realizada na posição Y: ${y}`);
      }
  
      console.log("Captura concluída. Gerando PDF...");
  
      const pdfData = await generatePdf(capturedImages, width, height, devicePixelRatio);
  
      console.log("PDF gerado. Salvando arquivo...");
  
      const blob = new Blob([pdfData], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
  
      chrome.downloads.download({
        url,
        filename: "pagina_capturada.pdf",
      });
  
      console.log("PDF salvo com sucesso!");
    } catch (error) {
      console.error("Erro ao capturar a página:", error);
    }
  });
  
  // Função para gerar PDF
  async function generatePdf(images, width, height, devicePixelRatio) {
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF();
  
    for (let i = 0; i < images.length; i++) {
      if (i > 0) pdf.addPage();
  
      const img = new Image();
      img.src = images[i];
  
      await new Promise((resolve) => (img.onload = resolve));
  
      const imgWidth = pdf.internal.pageSize.getWidth();
      const imgHeight = (height / images.length) / devicePixelRatio;
  
      pdf.addImage(img, "PNG", 0, 0, imgWidth, imgHeight);
    }
  
    return pdf.output("arraybuffer");
  }
  