document.getElementById("capture").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.action.onClicked.dispatch(tab);
  });
  