from django import forms
from django.core.exceptions import ValidationError
import os


class MultipleFileInput(forms.ClearableFileInput):
    """Widget personalizado para upload de múltiplos arquivos"""
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    """Campo personalizado para múltiplos arquivos"""
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput())
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single_file_clean = super().clean
        if isinstance(data, (list, tuple)):
            result = [single_file_clean(d, initial) for d in data]
        else:
            result = single_file_clean(data, initial)
        return result


class PDFMergeForm(forms.Form):
    """Formulário para upload e concatenação de PDFs"""
    
    pdfs = MultipleFileField(
        label='Arquivos PDF',
        help_text='Selecione pelo menos 2 arquivos PDF para concatenar',
        widget=MultipleFileInput(attrs={
            'multiple': True,
            'accept': 'application/pdf',
            'class': 'form-control',
            'id': 'pdfs'
        })
    )
    
    def clean_pdfs(self):
        files = self.cleaned_data.get('pdfs')
        
        if not files:
            raise ValidationError('Selecione pelo menos um arquivo PDF.')
        
        # Se é um único arquivo, transformar em lista
        if not isinstance(files, list):
            files = [files]
        
        if len(files) < 2:
            raise ValidationError('Selecione pelo menos dois arquivos PDF.')
        
        # Validar cada arquivo
        for file in files:
            # Verificar extensão
            if not file.name.lower().endswith('.pdf'):
                raise ValidationError(f'O arquivo {file.name} não é um PDF válido.')
            
            # Verificar tipo MIME
            if file.content_type != 'application/pdf':
                raise ValidationError(f'O arquivo {file.name} não é um PDF válido.')
            
            # Verificar tamanho (máximo 10MB por arquivo)
            if file.size > 10 * 1024 * 1024:
                raise ValidationError(f'O arquivo {file.name} é muito grande. Máximo 10MB por arquivo.')
            
            # Verificar cabeçalho PDF
            file.seek(0)
            header = file.read(4)
            file.seek(0)
            
            if header != b'%PDF':
                raise ValidationError(f'O arquivo {file.name} não é um PDF válido.')
        
        return files
