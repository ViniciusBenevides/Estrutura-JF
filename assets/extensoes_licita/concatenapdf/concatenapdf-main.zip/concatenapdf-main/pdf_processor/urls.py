from django.urls import path
from . import views

app_name = 'pdf_processor'

urlpatterns = [
    path('', views.home, name='home'),
    path('merge/', views.merge_pdfs, name='merge_pdfs'),
]
