from django.contrib import admin
from .models import PDFMergeJob


@admin.register(PDFMergeJob)
class PDFMergeJobAdmin(admin.ModelAdmin):
    """Admin para jobs de concatenação de PDFs"""
    
    list_display = ['id', 'created_at', 'files_count', 'status', 'output_filename']
    list_filter = ['status', 'created_at']
    search_fields = ['output_filename', 'error_message']
    readonly_fields = ['created_at']
    ordering = ['-created_at']
    
    fieldsets = (
        ('Informações Gerais', {
            'fields': ('created_at', 'files_count', 'status')
        }),
        ('Resultado', {
            'fields': ('output_filename',)
        }),
        ('Erro', {
            'fields': ('error_message',),
            'classes': ('collapse',)
        }),
    )
