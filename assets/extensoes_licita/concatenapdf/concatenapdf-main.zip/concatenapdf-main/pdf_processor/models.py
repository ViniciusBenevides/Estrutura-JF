from django.db import models
from django.utils import timezone


class PDFMergeJob(models.Model):
    """Modelo para armazenar informações sobre jobs de concatenação de PDFs"""
    
    created_at = models.DateTimeField(default=timezone.now)
    files_count = models.IntegerField(default=0)
    output_filename = models.CharField(max_length=255, blank=True)
    status = models.CharField(
        max_length=20,
        choices=[
            ('processing', 'Processando'),
            ('completed', 'Concluído'),
            ('error', 'Erro'),
        ],
        default='processing'
    )
    error_message = models.TextField(blank=True)
    
    class Meta:
        verbose_name = 'Job de Concatenação PDF'
        verbose_name_plural = 'Jobs de Concatenação PDF'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Job {self.id} - {self.files_count} arquivos - {self.status}"
