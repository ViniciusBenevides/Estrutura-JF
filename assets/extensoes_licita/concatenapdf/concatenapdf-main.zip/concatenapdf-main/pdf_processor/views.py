from django.shortcuts import render
from django.http import JsonResponse, HttpResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.conf import settings
from django.contrib import messages
import os
import tempfile
import uuid
from datetime import datetime
from PyPDF2 import PdfMerger
from .forms import PDFMergeForm
from .models import PDFMergeJob


def home(request):
    """View principal com formulário de upload"""
    form = PDFMergeForm()
    return render(request, 'home.html', {'form': form})


@require_http_methods(["POST"])
def merge_pdfs(request):
    """View para processar concatenação de PDFs"""
    
    # Verificar se é requisição AJAX
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    
    form = PDFMergeForm(request.POST, request.FILES)
    
    if not form.is_valid():
        error_messages = []
        for field, errors in form.errors.items():
            for error in errors:
                error_messages.append(str(error))
        
        if is_ajax:
            return JsonResponse({
                'success': False,
                'error': '; '.join(error_messages)
            })
        else:
            for error in error_messages:
                messages.error(request, error)
            return render(request, 'home.html', {'form': form})
    
    try:
        # Obter arquivos do formulário
        files = form.cleaned_data['pdfs']
        
        # Criar job no banco de dados
        job = PDFMergeJob.objects.create(
            files_count=len(files),
            status='processing'
        )
        
        # Criar merger
        merger = PdfMerger()
        
        # Adicionar cada PDF ao merger
        temp_files = []
        for file in files:
            # Salvar arquivo temporário
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
            for chunk in file.chunks():
                temp_file.write(chunk)
            temp_file.close()
            temp_files.append(temp_file.name)
            
            # Adicionar ao merger
            merger.append(temp_file.name)
        
        # Gerar nome único para o arquivo de saída
        output_filename = f"merged_{uuid.uuid4().hex[:8]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        output_path = os.path.join(settings.MEDIA_ROOT, 'downloads', output_filename)
        
        # Garantir que o diretório existe
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Salvar PDF concatenado
        merger.write(output_path)
        merger.close()
        
        # Limpar arquivos temporários
        for temp_file in temp_files:
            try:
                os.unlink(temp_file)
            except OSError:
                pass
        
        # Atualizar job
        job.output_filename = output_filename
        job.status = 'completed'
        job.save()
        
        if is_ajax:
            return JsonResponse({
                'success': True,
                'message': 'PDF concatenado com sucesso!',
                'download_url': f'/media/downloads/{output_filename}',
                'filename': 'merged.pdf'
            })
        else:
            # Para requisições não-AJAX, servir o arquivo diretamente
            with open(output_path, 'rb') as pdf_file:
                response = HttpResponse(pdf_file.read(), content_type='application/pdf')
                response['Content-Disposition'] = 'attachment; filename="merged.pdf"'
                return response
    
    except Exception as e:
        # Limpar arquivos temporários em caso de erro
        try:
            for temp_file in temp_files:
                os.unlink(temp_file)
        except:
            pass
        
        # Atualizar job com erro
        if 'job' in locals():
            job.status = 'error'
            job.error_message = str(e)
            job.save()
        
        error_message = f'Erro ao concatenar PDFs: {str(e)}'
        
        if is_ajax:
            return JsonResponse({
                'success': False,
                'error': error_message
            })
        else:
            messages.error(request, error_message)
            return render(request, 'home.html', {'form': PDFMergeForm()})
