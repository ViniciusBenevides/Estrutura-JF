_# Manual do Usuário - Concatenador de PDFs

## 📖 Sobre o Sistema

O **Concatenador de PDFs** é uma ferramenta web desenvolvida para unir múltiplos arquivos PDF em um único documento de forma rápida e intuitiva. O sistema foi projetado para ser simples, permitindo que qualquer usuário possa concatenar seus documentos sem complicações.

## 🎯 Para que serve?

*   **Unir** múltiplos documentos PDF em um só.
*   **Facilitar** o envio e o arquivamento de documentos relacionados.
*   **Otimizar** a organização de arquivos digitais.

## 🚀 Como usar o sistema

### 1. Acessando o Sistema

1.  Abra seu navegador de internet (Google Chrome, Firefox, etc.).
2.  Digite o endereço de acesso ao sistema na barra de endereços: `http://127.0.0.1:8000/` (para ambiente local).
3.  A página principal será carregada, exibindo a interface de concatenação.

### 🖥️ Interface do Sistema

A interface é limpa e direta, focada na funcionalidade principal.

![Interface do Sistema](static/images/arte03.png)

**📋 Elementos da Interface:**

1.  **Área de Upload (Arraste e Solte)**: A área central pontilhada onde você pode arrastar e soltar seus arquivos PDF.
2.  **Botão de Seleção de Arquivos**: Clicar na área de upload também abre uma janela para selecionar os arquivos do seu computador.
3.  **Botão "Enviar e Concatenar"**: Inicia o processo de união dos PDFs selecionados.
4.  **Área de Mensagens**: Exibe o status do processo, como o número de arquivos selecionados, mensagens de erro ou o link para download.

**💡 Fluxo de Uso:**

```
📄 Selecionar PDFs → ⚡ Enviar e Concatenar → 📊 Baixar Resultado
```

### 2. Selecionando os Arquivos PDF

Você pode adicionar os arquivos de duas maneiras:

*   **Arrastando e Soltando**:
    1.  Abra a pasta onde estão seus arquivos PDF.
    2.  Selecione todos os arquivos que deseja unir.
    3.  Arraste-os para dentro da área pontilhada na página do sistema.
*   **Clicando para Selecionar**:
    1.  Clique em qualquer lugar dentro da área pontilhada.
    2.  Uma janela do seu sistema operacional será aberta.
    3.  Navegue até a pasta, selecione os arquivos PDF desejados e clique em "Abrir".

Após a seleção, uma mensagem informará quantos arquivos foram carregados.

### 3. Processando os Arquivos

1.  Com pelo menos dois arquivos PDF selecionados, clique no botão **"Enviar e Concatenar"**.
2.  Aguarde enquanto o sistema processa os arquivos. O botão indicará "Processando...".

### 4. Baixando o Resultado

1.  Quando o processo for concluído, uma mensagem de sucesso será exibida.
2.  Um link para download aparecerá. O download deve iniciar automaticamente.
3.  Se o download não iniciar, clique no link **"Clique aqui para baixar o PDF concatenado"** para salvar o arquivo em seu computador.

## ⚠️ Requisitos e Limitações

### Arquivos Aceitos

*   ✅ **Formato**: Apenas arquivos com a extensão `.pdf`.
*   ✅ **Quantidade**: É necessário selecionar **pelo menos 2 arquivos** para a concatenação.
*   ✅ **Tamanho**: Cada arquivo individual não deve exceder 10MB.

### Limitações

*   ❌ Não processa PDFs protegidos por senha.
*   ❌ A ordem de concatenação segue a ordem em que os arquivos são selecionados.

## 🔧 Solução de Problemas

### Erro: "Selecione pelo menos dois arquivos PDF."

*   **Causa**: Você tentou concatenar menos de dois arquivos.
*   **Solução**: Certifique-se de selecionar dois ou mais arquivos PDF antes de clicar em "Enviar e Concatenar".

### Erro: "Apenas arquivos PDF são permitidos."

*   **Causa**: Um ou mais dos arquivos selecionados não estão no formato PDF.
*   **Solução**: Verifique os arquivos e selecione apenas aqueles com a extensão `.pdf`.

### Erro: "Erro na comunicação com o servidor."

*   **Causa**: Pode haver um problema com sua conexão de internet ou com o servidor.
*   **Solução**: Verifique sua conexão, recarregue a página e tente novamente.

### O arquivo não baixa automaticamente

*   **Solução**: Após a mensagem de sucesso, clique com o botão direito no link de download e escolha a opção "Salvar link como..." para baixar o arquivo manualmente.

## 📞 Suporte

Em caso de problemas persistentes ou dúvidas, entre em contato com a equipe de TI responsável.

---

**Versão do Manual**: 1.0
**Data**: Outubro de 2025
**Sistema**: Concatenador de PDFs v1.0 (Django)
_
